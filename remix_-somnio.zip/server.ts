/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { cleanSymbol } from "./src/utils/triggerCodex";

dotenv.config();

const app = express();
const PORT = 3000;

// Enable JSON body parsing with substantial body limits for text uploads
app.use(express.json({ limit: "10mb" }));

// Persistent Journal path
const DATA_DIR = path.join(process.cwd(), "data");
const JOURNAL_FILE = path.join(DATA_DIR, "journal.json");

// Ensure data folder and file exists with pre-seeded data
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const SEED_DATA = [
  {
    id: "seed-lighthouse",
    text: "In dieser visionären Traumsequenz erlebe ich einen Zustand vollkommener Schwerelosigkeit. Ich gleite mit mächtigen Flügeln über einen silbernen Ozean, dessen Wellen im fahlen Mondlicht metallisch glänzen. Mein Ziel ist ein monumentaler Leuchtturm, dessen Lichtkegel den dichten Nebel mit chirurgischer Präsision durchschneidet. Das Gefühl des Fliegens ist hyperrealistisch und vermittelt eine tiefe Sehnsucht nach Autonomie.",
    date: "24. OKTOBER 2023 • 04:12 UHR",
    rawDate: "2023-10-24T04:12:00.000Z",
    clarity: "Luzide",
    mood: "Glücklich",
    isLucid: true,
    analysis: {
      title: "Der Ruf des Leuchtturms",
      analysis: "In dieser visionären Traumsequenz erlebst du einen Zustand vollkommener Schwerelosigkeit. Du gleitest mit mächtigen Flügeln über einen silbernen Ozean, dessen Wellen im fahlen Mondlicht metallisch glänzen. Dein Ziel ist ein monumentaler Leuchtturm, dessen Lichtkegel den dichten Nebel mit chirurgischer Präsision durchschneidet. Das Gefühl des Fliegens ist hyperrealistisch und vermittelt eine tiefe Sehnsucht nach Autonomie.",
      lucidityScoreEstimate: 9,
      isLucid: true,
      interpretation: {
        meaning: "Der Leuchtturm steht für Orientierung in deinem Unterbewusstsein. Er signalisiert eine Phase der Klarheit nach einer Zeit der emotionalen Unsicherheit.",
        recommendation: "Das Fliegen über das Wasser deutet darauf hin, dass du beginnst, deine unbewussten Emotionen (der Ozean) mit Distanz und Souveränität zu betrachten."
      },
      emotions: {
        freude: 90,
        vertrauen: 80,
        angst: 0,
        ueberraschung: 10,
        traurigkeit: 0,
        ekel: 0,
        wut: 0,
        erwartung: 70
      },
      symbols: {
        characters: [{ name: "Flügel", emoji: "🪶" }],
        locations: [{ name: "Silberner Ozean", emoji: "🌊" }],
        objects: [{ name: "Leuchtturm", emoji: "🏮" }]
      },
      dreamSigns: ["Leuchtturm", "Flügel"]
    }
  },
  {
    id: "seed-forest",
    text: "Ich bin durch einen dichten Wald gegangen, in dem die Eichen mit sanften, tiefen Stimmen sprachen und mir Moosteppiche den Weg wiesen. Ein alter Hirsch mit leuchtendem Geweih stand am Bachufer und neigte den Kopf zum Gruß.",
    date: "19. JUNI 2026 • 07:45 UHR",
    rawDate: "2026-06-19T07:45:00.000Z",
    clarity: "Mittel",
    mood: "Neutral",
    isLucid: false,
    analysis: {
      title: "Der sprechende Wald",
      analysis: "Du wanderst durch ein organisch-pulsierendes Waldlabyrinth, das Geborgenheit vermittelt. Sprechende Bäume symbolisieren ancestrale Weisheit und die Sehnsucht nach natürlicher Erdung. Der Hirsch dient als majestätischer Seelenführer (Archetypus des weisen Begleiters).",
      lucidityScoreEstimate: 4,
      isLucid: false,
      interpretation: {
        meaning: "Der sprechende Wald repräsentiert deine Sehnsucht, auf verdrängtes inneres Wissen und beruhigende Instinkte zuzugreifen.",
        recommendation: "Achte im Alltag auf nonverbale Signale deines Körpers und suche Momente der Stille in der Natur."
      },
      emotions: {
        freude: 30,
        vertrauen: 85,
        angst: 5,
        ueberraschung: 40,
        traurigkeit: 0,
        ekel: 0,
        wut: 0,
        erwartung: 60
      },
      symbols: {
        characters: [{ name: "Hirsch", emoji: "🦌" }, { name: "Baum", emoji: "🌳" }],
        locations: [{ name: "Wald", emoji: "🌲" }],
        objects: [{ name: "Geweih", emoji: "🪵" }]
      },
      dreamSigns: ["Wald"]
    }
  }
];

if (!fs.existsSync(JOURNAL_FILE)) {
  fs.writeFileSync(JOURNAL_FILE, JSON.stringify([], null, 2), "utf-8");
}

// REST GET Journal
app.get("/api/journal", (req, res) => {
  try {
    const { username } = req.query;
    if (!username) {
      return res.status(400).json({ error: "Benutzername erforderlich." });
    }

    const data = fs.readFileSync(JOURNAL_FILE, "utf-8");
    let currentData = JSON.parse(data);

    // Filter by username (case-insensitive)
    let userEntries = currentData.filter((d: any) => 
      d.username && d.username.toLowerCase() === username.toString().toLowerCase()
    );

    res.json(userEntries);
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Lesen des Traumjournals." });
  }
});

// REST POST Journal (Save dream)
app.post("/api/journal", (req, res) => {
  try {
    const newEntry = req.body;
    if (!newEntry || !newEntry.text || !newEntry.username) {
      return res.status(400).json({ error: "Ungültiger Traumeintrag oder Benutzername fehlt." });
    }

    const currentData = JSON.parse(fs.readFileSync(JOURNAL_FILE, "utf-8"));
    
    // Check if entry already exists to allow update, otherwise prepend
    const existingIndex = currentData.findIndex((d: any) => d.id === newEntry.id);
    if (existingIndex !== -1) {
      currentData[existingIndex] = newEntry;
    } else {
      currentData.unshift(newEntry);
    }

    fs.writeFileSync(JOURNAL_FILE, JSON.stringify(currentData, null, 2), "utf-8");
    res.json({ success: true, entry: newEntry });
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Speichern des Traums." });
  }
});

// REST DELETE Journal (Delete dream)
app.delete("/api/journal/:id", (req, res) => {
  try {
    const { id } = req.params;
    const currentData = JSON.parse(fs.readFileSync(JOURNAL_FILE, "utf-8"));
    const updatedData = currentData.filter((d: any) => d.id && d.id.toString() !== id.toString());
    fs.writeFileSync(JOURNAL_FILE, JSON.stringify(updatedData, null, 2), "utf-8");
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: "Fehler beim Löschen des Traums." });
  }
});

// AI Analyze Endpoint using Gemini SDK Server-side
app.post("/api/analyze", async (req, res) => {
  try {
    const { text, clarity, mood, isLucidUser } = req.body;
    console.log(`[Somnio Server] Analyse-Anfrage erhalten (Länge: ${text ? text.length : 0} Zeichen)`);

    if (!text || text.trim().length === 0) {
      return res.status(400).json({ error: "Bitte gib einen Traumtext ein." });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const isPlaceholder = !apiKey || 
      apiKey.trim() === "" || 
      apiKey === "MY_GEMINI_API_KEY" || 
      apiKey === "MY_API_KEY" || 
      apiKey.includes("PLACEHOLDER") || 
      apiKey.startsWith("MY_");

    if (isPlaceholder) {
      console.warn("[Somnio Server] WARNUNG: GEMINI_API_KEY fehlt oder ist ein unkonfigurierter Platzhalter. Verwende das hochwertige lokale Fallback-Modell.");
      const mockedAnalysis = generateMockAnalysis(text, clarity, mood, isLucidUser);
      return res.json(mockedAnalysis);
    }

    console.log("[Somnio Server] GEMINI_API_KEY vorhanden und scheint gültig zu sein. Initialisiere GoogleGenAI client...");
    // Lazy initialize Gemini clients on request
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });

    console.log("[Somnio Server] Sende Anfrage an Gemini API (Modell: gemini-3.5-flash)...");

    const systemInstruction = `
Du bist ein psychoanalytischer Traumforscher, Experte für archetypische Symbolik nach C.G. Jung sowie kognitive Neurobiologie des Schlafes.
Arbeite auf Deutsch.

Regeln & Prompt-Architektur:
1. Die Traumdeutung im Feld "analysis" MUSS extrem kompakt sein - maximal 50 Wörter (nicht viel länger). Extrapoliere eine tiefgründige Deutung basierend auf Jungs Archetypenlehre, aber halte sie streng unter der 50-Wörter-Grenze (ca. 2-3 kurze Sätze).
2. Filter für Arrays (characters, locations, objects): Trage für jeden Eintrag strengstens exakt ein einziges, prägnantes Hauptwort ein.
   - Verboten: Phrasen wie "Krokodil als unbewusste Angst" -> Erlaubt ist nur "Krokodil".
   - Verboten: Modifizierte Substantive wie "strenger Lehrer" -> Erlaubt ist nur "Lehrer".
3. Fehlender Kontext: Gibt der Traumtext keine validen Zeichen für eine Kategorie her, befehle dem Array absolut leer ([]) zu sein. Niemals Platzhalter wie "Kein Kontext", "unbekannt" oder "keine Symbole" eintragen! Halte das Array in diesem Fall leer.
4. Zitate-Syntaxregel (JSON-Kollisionsschutz): Um JSON-Parserfehler im String durch doppelte Anführungszeichen (") zu verhindern, müssen alle direkten Reden oder Betonungen mit einfachen Anführungszeichen (') oder Gänsefüßchen (»...« oder „...“) maskiert werden.

Gefordertes JSON-Schema:
{
  "title": "Poetischer, atmosphärischer Titel basierend auf der Traumstimmung",
  "analysis": "Extrem kurze, präzise psychologische Traumdeutung auf Deutsch mit MAXIMAL 50 WÖRTERN.",
  "lucidityScoreEstimate": 1, // Integer von 1-10 für die erahnte Luzidität
  "isLucid": false, // Erkannter Bewusstseinszustand im Traum (Boolean)
  "interpretation": {
    "meaning": "Kurze, prägnante Zusammenfassung der theoretischen Bedeutung",
    "recommendation": "Konkreter, alltagstauglicher Tipp zur Integration ins Wachleben"
  },
  "emotions": {
    "freude": 0,       // Integer 0-100%
    "vertrauen": 0,    // Integer 0-100%
    "angst": 0,        // Integer 0-100%
    "ueberraschung": 0,// Integer 0-100%
    "traurigkeit": 0,  // Integer 0-100%
    "ekel": 0,         // Integer 0-100%
    "wut": 0,          // Integer 0-100%
    "erwartung": 0     // Integer 0-100%
  },
  "symbols": {
    "characters": [{"name": "Symbolwort", "emoji": "🧑"}],
    "locations": [{"name": "Symbolwort", "emoji": "🏫"}],
    "objects": [{"name": "Symbolwort", "emoji": "⏰"}]
  },
  "dreamSigns": ["Symbolwort"],
  "illustrationKeyword": "forest" // Ein prägnantes, stärkstes bildliches Hauptwort auf Englisch (z.B. "forest", "ocean", "flying", "galaxy", "neon-city", "shadow", "desert", "castle", "clouds", "dreamy-portal")
}
`;

    const userPrompt = `
Traumtext:
"${text}"

Metadaten (Auswahl des Träumers):
- Klarheitsgrad: ${clarity}
- Gewählte Stimmung: ${mood}
- Vom Träumer als Klartraum deklariert: ${isLucidUser ? "Ja" : "Nein"}

Führe eine tiefschürfende Traumforschung durch und antworte STRENGSTENS im geforderten JSON-Format.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: userPrompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });

    console.log("[Somnio Server] Gemini-Antwort empfangen. Analysiere Antwort...");
    const rawText = response.text || "{}";
    let parsed: any;
    try {
      parsed = JSON.parse(rawText.trim());
      console.log("[Somnio Server] Traum-JSON erfolgreich direkt geparst.");
    } catch (parseErr) {
      console.warn("[Somnio Server] Warnung: Gemini-Antwort war nicht direkt als JSON parsbar. Versuche Regex-Extraktion...", rawText);
      // Clean up brackets or characters
      const jsonMatch = rawText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsed = JSON.parse(jsonMatch[0]);
        console.log("[Somnio Server] Traum-JSON erfolgreich über Regex extrahiert.");
      } else {
        throw new Error("Fehler beim Verarbeiten der Traumantwort. Keine gültige JSON-Struktur.");
      }
    }

    // --- STRUCTURAL HEALING & DEEP MERGER ---
    // Ensure all critical fields exist and contain safe fallback presets so that frontend never breaks
    const defaultData = {
      title: "Traum-Einsicht",
      analysis: text.length > 150 ? text.substring(0, 150) + "..." : text,
      lucidityScoreEstimate: isLucidUser ? 8 : (clarity === "Luzide" ? 8 : (clarity === "Mittel" ? 5 : 2)),
      isLucid: isLucidUser || (clarity === "Luzide"),
      interpretation: {
        meaning: "Dein Traum spiegelt tiefere psychologische Prozesse deiner emotionalen Erlebniswelt wider.",
        recommendation: "Es empfiehlt sich, die Hauptsymbole des Traumes in ein kreatives Format zu übertragen (z. B. Skizze), um sie bewusster zu verankern."
      },
      emotions: {
        freude: mood === "Glücklich" ? 75 : 0,
        vertrauen: 50,
        angst: mood === "Ängstlich" ? 75 : 0,
        ueberraschung: 20,
        traurigkeit: 0,
        ekel: 0,
        wut: 0,
        erwartung: 40
      },
      symbols: {
        characters: [],
        locations: [],
        objects: []
      },
      dreamSigns: []
    };

    // Deep merge objects/nested properties
    parsed = {
      ...defaultData,
      ...parsed,
      interpretation: {
        ...defaultData.interpretation,
        ...(parsed.interpretation || {})
      },
      emotions: {
        ...defaultData.emotions,
        ...(parsed.emotions || {})
      },
      symbols: {
        ...defaultData.symbols,
        ...(parsed.symbols || {})
      }
    };

    // --- TRIGGER CODEX (STAGE 1-6) POST-PROCESSING ON THE SERVER ---
    // Apply server-side guarantee to clean all entries to exactly one normal noun
    if (parsed.symbols) {
      if (Array.isArray(parsed.symbols.characters)) {
        parsed.symbols.characters = parsed.symbols.characters
          .map((c: any) => ({ ...c, name: cleanSymbol(c.name || "") }))
          .filter((c: any) => c.name !== "");
      }
      if (Array.isArray(parsed.symbols.locations)) {
        parsed.symbols.locations = parsed.symbols.locations
          .map((l: any) => ({ ...l, name: cleanSymbol(l.name || "") }))
          .filter((l: any) => l.name !== "");
      }
      if (Array.isArray(parsed.symbols.objects)) {
        parsed.symbols.objects = parsed.symbols.objects
          .map((o: any) => ({ ...o, name: cleanSymbol(o.name || "") }))
          .filter((o: any) => o.name !== "");
      }
    }

    if (Array.isArray(parsed.dreamSigns)) {
      parsed.dreamSigns = parsed.dreamSigns
        .map((ds: string) => cleanSymbol(ds))
        .filter((ds: string) => ds !== "");
    }

    // Adjust user overrides
    if (typeof isLucidUser === "boolean" && isLucidUser) {
      parsed.isLucid = true;
    } else if (clarity === "Luzide") {
      parsed.isLucid = true;
    }

    // Overwrite emotions with safe number bounds
    if (parsed.emotions) {
      for (const emotion of Object.keys(parsed.emotions)) {
        let val = Number(parsed.emotions[emotion] || 0);
        if (isNaN(val)) val = 0;
        parsed.emotions[emotion] = Math.max(0, Math.min(100, val));
      }
    }

    // Attach premium custom dynamic illustration URL
    parsed.imageUrl = getDreamIllustrationUrl(parsed.illustrationKeyword, text, mood);

    res.json(parsed);
  } catch (err: any) {
    console.error("Fehler im Analyse-Handler:", err);
    res.status(500).json({
      error: "Traumanalyse konnte nicht durchgeführt werden.",
      details: err.message || err
    });
  }
});

/**
 * Procedural mock generation if API key is missing (ensures a great sandbox experience)
 */
function generateMockAnalysis(text: string, clarity: string, mood: string, isLucidUser: boolean) {
  const isLucid = isLucidUser || (clarity === "Luzide");
  const score = isLucid ? 9 : (clarity === "Mittel" ? 5 : 2);
  
  // Basic smart mapping based on dream keywords with strict under-50-words constraint
  let title = "Der mystische Traumschleier";
  let analysis = `Dein Traum spiegelt tiefe Impulse wider. Die emotionale Färbung (${mood === "Glücklich" ? "Freude" : (mood === "Ängstlich" ? "Besorgnis" : "Neutralität")}) verknüpft Erlebtes mit deinen Wünschen. Durch die ${clarity}-Klarheit bist du besonders nah an deinen unbewussten Triebfedern.`;
  let meaning = "Dein Traum symbolisiert den Wunsch nach psychischer Navigation und Entlastung im Alltag.";
  let recommendation = "Führe täglich drei Reality-Checks durch und notiere kleinste Naturreize.";
  
  const keywords: string[] = [];
  const chars: {name: string, emoji: string}[] = [];
  const locs: {name: string, emoji: string}[] = [];
  const objs: {name: string, emoji: string}[] = [];

  const textLower = text.toLowerCase();
  
  if (textLower.includes("fliegen") || textLower.includes("flug") || textLower.includes("gleiten")) {
    title = "Der schwerelose Schwingenflug";
    analysis = "Das Fliegen ist ein Befreiungsarchetyp nach C.G. Jung. Dein Geist steigt über Alltagslasten empor. Nutze dieses Gefühl von Autonomie und Weitblick, um heute eine offene Entscheidung mutig anzugehen.";
    meaning = "Fliegen symbolisiert deine Sehnsucht nach Selbstbestimmung und das Loslassen von kognitiven Alltagsstrukturen.";
    recommendation = "Nimm das Gefühl der Schwerelosigkeit mit in den Tag: Gewinne gelassenen Abstand.";
    objs.push({ name: "Flügel", emoji: "🪶" });
    keywords.push("Flügel");
  }

  if (textLower.includes("wasser") || textLower.includes("meer") || textLower.includes("ozean") || textLower.includes("see")) {
    if (!keywords.includes("Wasser")) {
      locs.push({ name: "Ozean", emoji: "🌊" });
      keywords.push("Ozean");
      if (!textLower.includes("fliegen")) {
        analysis = "Wasser repräsentiert dein emotionales Erleben und das fließende kollektive Unbewusste. Dich darin zu bewegen, ohne unterzugehen, zeigt deine tiefe seelische Resilienz und deine Fähigkeit zur Anpassung.";
      }
    }
  }

  if (textLower.includes("wald") || textLower.includes("bäume") || textLower.includes("park")) {
    title = "Das Raunen der spechenden Eichen";
    locs.push({ name: "Wald", emoji: "🌲" });
    keywords.push("Wald");
    if (!textLower.includes("fliegen") && !textLower.includes("wasser")) {
      analysis = "Der dichte Wald symbolisiert die seelische Wildnis und unbewusste Erkenntnisse. Die Bäume stehen für deine Gedankenstrukturen. Das Raunen weist auf feine Impulse hin, die gehört werden wollen.";
    }
  }

  if (chars.length === 0) chars.push({ name: "Schatten", emoji: "👤" });
  if (locs.length === 0) locs.push({ name: "Horizont", emoji: "🌅" });
  if (objs.length === 0) objs.push({ name: "Schlüssel", emoji: "🔑" });
  if (keywords.length === 0) keywords.push("Horizont", "Schlüssel");

  // Emotion ratings based on users choice
  let freude = mood === "Glücklich" ? 85 : 15;
  let angst = mood === "Ängstlich" ? 90 : 5;
  let vertrauen = isLucid ? 80 : 40;
  let ueberraschung = 50;
  let traurigkeit = mood === "Neutral" ? 10 : 25;
  let ekel = 0;
  let wut = 0;
  let erwartung = 60;

  return {
    title,
    analysis,
    lucidityScoreEstimate: score,
    isLucid,
    interpretation: {
      meaning: cleanSymbol(meaning), // Ensure server trigger-codex cleaned
      recommendation
    },
    emotions: {
      freude,
      vertrauen,
      angst,
      ueberraschung,
      traurigkeit,
      ekel,
      wut,
      erwartung
    },
    symbols: {
      characters: chars.map(c => ({ ...c, name: cleanSymbol(c.name) })).filter(c => c.name !== ""),
      locations: locs.map(l => ({ ...l, name: cleanSymbol(l.name) })).filter(l => l.name !== ""),
      objects: objs.map(o => ({ ...o, name: cleanSymbol(o.name) })).filter(o => o.name !== "")
    },
    dreamSigns: keywords.map(ds => cleanSymbol(ds)).filter(ds => ds !== ""),
    imageUrl: getDreamIllustrationUrl(undefined, text, mood)
  };
}

/**
 * Maps dream semantics and moods to atmospheric surrealist artwork.
 */
function getDreamIllustrationUrl(keyword: string | undefined, text: string, mood: string): string {
  const images: Record<string, string> = {
    forest: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=800&q=80",
    ocean: "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=800&q=80",
    water: "https://images.unsplash.com/photo-1505118380757-91f5f5632de0?auto=format&fit=crop&w=800&q=80",
    flying: "https://images.unsplash.com/photo-1534067783941-51c9c23ecefd?auto=format&fit=crop&w=800&q=80",
    clouds: "https://images.unsplash.com/photo-1534067783941-51c9c23ecefd?auto=format&fit=crop&w=800&q=80",
    sky: "https://images.unsplash.com/photo-1495195129352-aeb325a55b65?auto=format&fit=crop&w=800&q=80",
    galaxy: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=800&q=80",
    stars: "https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=800&q=80",
    shadow: "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&w=800&q=80",
    dark: "https://images.unsplash.com/photo-1509248961158-e54f6934749c?auto=format&fit=crop&w=800&q=80",
    desert: "https://images.unsplash.com/photo-1509316785289-025f5b846b35?auto=format&fit=crop&w=800&q=80",
    city: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=800&q=80",
    neon: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?auto=format&fit=crop&w=800&q=80",
    castle: "https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&w=800&q=80",
    portal: "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=800&q=80",
    abyss: "https://images.unsplash.com/photo-1682687220063-4742bd7fd538?auto=format&fit=crop&w=800&q=80",
    nature: "https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=800&q=80",
    house: "https://images.unsplash.com/photo-1508849789987-4e5333c12b78?auto=format&fit=crop&w=800&q=80",
    fire: "https://images.unsplash.com/photo-1508873696983-2df519f0397e?auto=format&fit=crop&w=800&q=80"
  };

  const kw = keyword ? keyword.toLowerCase().trim() : "";
  if (kw && images[kw]) {
    return images[kw];
  }

  // Check substrings of keyword if available
  if (kw) {
    for (const key of Object.keys(images)) {
      if (kw.includes(key) || key.includes(kw)) {
        return images[key];
      }
    }
  }

  const textLower = text.toLowerCase();
  if (textLower.includes("fliegen") || textLower.includes("flug") || textLower.includes("gleit") || textLower.includes("luft") || textLower.includes("fly")) {
    return images.flying;
  }
  if (textLower.includes("wasser") || textLower.includes("ozean") || textLower.includes("meer") || textLower.includes("see") || textLower.includes("well") || textLower.includes("ocean") || textLower.includes("water")) {
    return images.ocean;
  }
  if (textLower.includes("wald") || textLower.includes("bäume") || textLower.includes("natur") || textLower.includes("baum") || textLower.includes("wald") || textLower.includes("forst") || textLower.includes("forest")) {
    return images.forest;
  }
  if (textLower.includes("weltall") || textLower.includes("sterne") || textLower.includes("kosmos") || textLower.includes("planet") || textLower.includes("space") || textLower.includes("galaxy")) {
    return images.galaxy;
  }
  if (textLower.includes("stadt") || textLower.includes("gebäude") || textLower.includes("haus") || textLower.includes("turm") || textLower.includes("city") || textLower.includes("strasse")) {
    return images.city;
  }
  if (mood === "Ängstlich" || textLower.includes("angst") || textLower.includes("albtraum") || textLower.includes("schreck") || textLower.includes("monster") || textLower.includes("dunkel")) {
    return images.shadow;
  }

  // Fallback portal or scenery
  const code = text.length % 5;
  if (code === 0) return images.portal;
  if (code === 1) return "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80"; // warm sunset
  if (code === 2) return "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80"; // dream mountains
  if (code === 3) return "https://images.unsplash.com/photo-1509316785289-025f5b846b35?auto=format&fit=crop&w=800&q=80"; // desert
  return "https://images.unsplash.com/photo-1495195129352-aeb325a55b65?auto=format&fit=crop&w=800&q=80"; // clouds sky
}

// Assemble Express Server with Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Somnio Server] Läuft erfolgreich auf http://0.0.0.0:${PORT}`);
  });
}

startServer();
