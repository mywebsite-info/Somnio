/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Clock, Eye, Moon, Zap, Sparkles, X, Info, Volume2, AlertCircle } from "lucide-react";
import { calculateSleepCycles } from "../utils/sleepMath";
import { RemPeak } from "../types";

interface SettingsModalProps {
  onClose: () => void;
  onClearJournal: () => void;
  onLogout: () => void;
}

export default function SettingsModal({ onClose, onClearJournal, onLogout }: SettingsModalProps) {
  const [sleepTime, setSleepTime] = useState("23:00");
  const [calculatedPeaks, setCalculatedPeaks] = useState<RemPeak[]>([]);

  useEffect(() => {
    // Recalculate stages on sleepTime adjust
    const p = calculateSleepCycles(sleepTime);
    setCalculatedPeaks(p);
  }, [sleepTime]);

  const handleTestNotification = () => {
    alert("Astraler Weckton-Test: Ein sanftes Klang-Signal wird zukünftig an deinem REM-Spitzenpunkt von Phase 4 abgespielt.");
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-[100] flex items-center justify-center p-4">
      <div className="bg-[#12181e] border border-white/10 rounded-2xl max-w-lg w-full flex flex-col shadow-[0_0_50px_rgba(47,217,244,0.15)] overflow-hidden max-h-[90vh] animate-scale-up">
        
        {/* Header toolbar */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-white/5 bg-[#161c22]">
          <div className="flex items-center gap-2">
            <Moon className="w-5 h-5 text-[#8aebff]" />
            <h3 className="font-headline-md text-base md:text-lg font-bold font-display text-[#8aebff]">
              Chronobiologische Einstellungen
            </h3>
          </div>
          <button
            id="settings-close-x"
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/5 text-[#bbc9cd] hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content catalog */}
        <div className="p-6 overflow-y-auto space-y-6 custom-scrollbar text-sm">
          
          {/* Section 1: Schlafphasen-Modellierung */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-[#2fd9f4] font-semibold border-b border-white/5 pb-2">
              <Clock className="w-4 h-4" />
              <span>Predictive Schlafphasen (REM-Peak)</span>
            </div>
            
            <p className="text-xs text-[#bbc9cd] leading-relaxed">
              Träger von Klarträumen benötigen eine präzise zeitliche Lokalisierung ihrer intensivsten Traumphasen. Konfiguriere deine typische Einschlafzeit, um die optimalen Zeitpunkte für luzides Aufwachen (WBTB) zu bestimmen:
            </p>

            {/* Time select slider or input */}
            <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/5">
              <label className="text-xs font-bold text-[#bbc9cd] uppercase whitespace-nowrap">
                Einschlaf-Uhrzeit:
              </label>
              <input
                id="settings-sleep-input"
                type="time"
                value={sleepTime}
                onChange={(e) => setSleepTime(e.target.value)}
                className="bg-[#1a2026] text-[#8aebff] font-mono border border-[#444173] rounded-lg px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#2fd9f4] w-full text-center"
              />
            </div>

            {/* Predicted Peak Interval timeline */}
            <div className="space-y-3">
              <span className="text-[10px] font-bold uppercase text-[#bbc9cd]/60 block mb-1">
                Berechnete REM-Ermittlung
              </span>
              
              {calculatedPeaks.map((peak) => (
                <div
                  key={peak.phase}
                  className={`flex items-center justify-between p-2.5 rounded-lg border text-xs transition-all ${
                    peak.isOptimalAnker
                      ? "bg-[#2fd9f4]/15 border-[#2fd9f4] shadow-[0_0_10px_rgba(47,217,244,0.1)] text-[#dde3eb]"
                      : "bg-[#1a2026]/40 border-white/5 text-[#bbc9cd]/80"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                        peak.isOptimalAnker
                          ? "bg-[#2fd9f4] text-[#00363e]"
                          : "bg-white/5 text-[#bbc9cd]"
                      }`}
                    >
                      {peak.phase}
                    </span>
                    <span className="font-semibold text-xs text-[#dde3eb]">
                      REM-Phase {peak.phase} (~{peak.phase * 1.5} Std. Schlaf)
                    </span>
                  </div>

                  <div className="text-right flex items-center gap-3">
                    <span className="font-mono text-[#8aebff] font-bold text-xs">
                      {peak.timeString}
                    </span>
                    {peak.isOptimalAnker ? (
                      <span className="bg-[#2fd9f4] text-[#00363e] text-[8px] font-bold uppercase px-1.5 py-0.5 rounded animate-pulse">
                        GOLD-PEAK (WBTB)
                      </span>
                    ) : (
                      <span className="text-[10px] text-[#bbc9cd]/45">
                        {peak.lucidityChance}% Chance
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <div className="bg-[#bfbbf5]/5 border border-[#bfbbf5]/10 p-3 rounded-lg flex gap-2 text-xs text-[#ddd9ff]">
              <Info className="w-4 h-4 text-[#ddd9ff] shrink-0" />
              <p className="leading-relaxed">
                <strong>Ankertipp:</strong> Stelle dir einen dezenten Vibrationswecker auf die vierte Phase um <strong>{calculatedPeaks.find(p => p.isOptimalAnker)?.timeString || "04:15"}</strong>. Nutze dieses kurze 5-Minuten-Aufwachen, um deinen Realitätssinn zu schärfen, und gleite anschließend mit MILD-Formeln zurück in den Traum.
              </p>
            </div>
          </div>

          {/* Section 2: Audio & System triggers */}
          <div className="space-y-4 pt-2 border-t border-white/5">
            <div className="flex items-center gap-2 text-[#ddb8ff] font-semibold border-b border-white/5 pb-2">
              <Zap className="w-4 h-4" />
              <span>Klangreize & Weck-Therapie</span>
            </div>

            <div className="flex items-center justify-between bg-white/5 p-3 rounded-xl border border-white/5">
              <div>
                <span className="text-xs font-semibold text-[#dde3eb] block">Astraler Puls-Ton</span>
                <span className="text-[11px] text-[#bbc9cd]/60">Sanfter Sinus-Ton für luzide Triggerung</span>
              </div>
              <button
                onClick={handleTestNotification}
                className="p-2 bg-white/5 hover:bg-white/10 rounded-full text-[#8aebff] transition-colors cursor-pointer"
                title="Testen"
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Section 3: Reset Actions */}
          <div className="space-y-4 pt-2 border-t border-white/5">
            <div className="flex items-center gap-2 text-red-400 font-semibold border-b border-white/5 pb-2">
              <AlertCircle className="w-4 h-4" />
              <span>Gefahrenzone</span>
            </div>

            <div className="flex items-center justify-between text-xs">
              <div className="space-y-0.5">
                <span className="font-semibold text-[#dde3eb] block">Journal-Cache leeren</span>
                <span className="text-[11px] text-[#bbc9cd]/50">Alle aufgezeichneten Träume restlos löschen</span>
              </div>
              <button
                onClick={() => {
                  const yes = window.confirm("Bist du absolut sicher? Dies löscht alle aufgezeichneten Journalträume unwiderruflich.");
                  if (yes) {
                    onClearJournal();
                  }
                }}
                className="px-4 py-2 border border-red-500/30 hover:bg-red-500/10 text-red-400 rounded-lg font-semibold tracking-wide transition-colors cursor-pointer text-center"
              >
                Alles löschen
              </button>
            </div>

            <div className="flex items-center justify-between text-xs pt-4 border-t border-white/5">
              <div className="space-y-0.5">
                <span className="font-semibold text-red-300 block">Abmelden / Logout</span>
                <span className="text-[11px] text-[#bbc9cd]/50">Benutzerkonto verlassen und Sitzung beenden</span>
              </div>
              <button
                onClick={onLogout}
                className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-100 border border-red-500/40 rounded-lg font-semibold tracking-wide transition-all cursor-pointer text-center"
              >
                Abmelden
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
