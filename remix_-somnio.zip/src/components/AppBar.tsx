/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ArrowLeft, Share2, Settings, User } from "lucide-react";

interface AppBarProps {
  title?: string;
  showBack?: boolean;
  onBack?: () => void;
  showProfile?: boolean;
  onProfileClick?: () => void;
  onSettingsClick?: () => void;
  onShareClick?: () => void;
}

export default function AppBar({
  title = "Somnio",
  showBack = false,
  onBack,
  showProfile = false,
  onProfileClick,
  onSettingsClick,
  onShareClick,
}: AppBarProps) {
  return (
    <header className="fixed top-0 left-0 right-0 w-full z-50 bg-[#0e141a]/60 backdrop-blur-xl border-b border-white/10 shadow-sm">
      <div className="flex justify-between items-center px-6 h-16 max-w-[1200px] mx-auto w-full">
        <div className="flex items-center gap-3">
          {showBack ? (
            <button
              id="header-back-btn"
              onClick={onBack}
              className="text-[#8aebff] p-1.5 rounded-full hover:bg-white/5 active:scale-95 transition-all duration-200"
              aria-label="Zurück"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          ) : showProfile ? (
            <button
              id="header-profile-btn"
              onClick={onProfileClick}
              className="text-[#8aebff] p-1.5 rounded-full hover:bg-white/5 active:scale-95 transition-all duration-200"
              aria-label="Profil"
            >
              <User className="w-5 h-5" />
            </button>
          ) : null}
          <h1 className="font-headline-lg-mobile text-headline-lg-mobile md:font-headline-lg md:text-headline-lg text-[#2fd9f4] tracking-tighter cursor-pointer">
            {title}
          </h1>
        </div>

        <div className="flex items-center gap-2">
          {onShareClick && (
            <button
              id="header-share-btn"
              onClick={onShareClick}
              className="p-2 text-[#bbc9cd] hover:text-[#2fd9f4] rounded-full hover:bg-white/5 transition-colors duration-200"
              aria-label="Teilen"
            >
              <Share2 className="w-4 h-4" />
            </button>
          )}
          {onSettingsClick && (
            <button
              id="header-settings-btn"
              onClick={onSettingsClick}
              className="p-2 text-[#bbc9cd] hover:text-[#2fd9f4] rounded-full hover:bg-white/5 transition-colors duration-200"
              aria-label="Einstellungen"
            >
              <Settings className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
