/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Moon, ShieldCheck, User, Sparkles, CloudCheck, ArrowRight } from "lucide-react";

interface LoginScreenProps {
  onLogin: (username: string) => void;
}

export default function LoginScreen({ onLogin }: LoginScreenProps) {
  const [nameInput, setNameInput] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = nameInput.trim();
    if (cleanName.length < 2) {
      setError("Der Benutzername muss mindestens 2 Zeichen lang sein.");
      return;
    }
    setError("");
    onLogin(cleanName);
  };

  return (
    <div className="fixed inset-0 z-[250] bg-[#090d11] flex flex-col justify-between p-8 text-center overflow-y-auto">
      
      {/* Immersive space blur highlights */}
      <div className="absolute top-[20%] left-1/2 -translate-x-1/2 w-96 h-96 bg-[#8aebff]/5 blur-[140px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-[20%] left-1/4 w-80 h-80 bg-[#ddb8ff]/5 blur-[120px] rounded-full pointer-events-none"></div>

      {/* Header Badge */}
      <div className="pt-6 relative z-10 flex justify-center">
        <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full">
          <Moon className="w-4 h-4 text-[#8aebff] animate-pulse" />
          <span className="font-mono text-[9px] uppercase tracking-widest text-[#bbc9cd]">
            Somnio Cloud-Netzwerk
          </span>
        </div>
      </div>

      {/* Core Auth Dialog card */}
      <div className="my-auto max-w-md w-full mx-auto relative z-10 py-10 px-8 bg-[#12181e]/60 border border-white/5 backdrop-blur-md rounded-3xl shadow-[0_20px_50px_rgba(0,0,0,0.5)]">
        
        {/* Animated Icon Glow */}
        <div className="relative w-16 h-16 mx-auto mb-6 flex items-center justify-center">
          <div className="absolute inset-0 bg-[#2fd9f4]/20 rounded-full blur-xl animate-pulse"></div>
          <div className="w-16 h-16 bg-[#162128] border border-[#2fd9f4]/30 rounded-2xl flex items-center justify-center shadow-lg">
            <Sparkles className="w-7 h-7 text-[#8aebff] animate-spin" style={{ animationDuration: "12s" }} />
          </div>
        </div>

        <h1 className="font-display text-3xl font-black tracking-tight text-white mb-2">
          Betrete Somnio
        </h1>
        
        <p className="text-xs text-[#bbc9cd] leading-relaxed max-w-sm mx-auto mb-8">
          Identifiziere dich mit deinem Benutzernamen. Deine Traumaufzeichnungen werden synchronisiert und dauerhaft in unserer Cloud gesichert.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#bbc9cd]/50">
              <User className="w-4 h-4" />
            </span>
            <input
              id="username-input"
              type="text"
              placeholder="Dein Benutzername (z. B. Anton)"
              value={nameInput}
              onChange={(e) => {
                setNameInput(e.target.value);
                if (e.target.value.trim().length >= 2) setError("");
              }}
              className="w-full pl-11 pr-4 py-3.5 bg-[#172026] hover:bg-[#1a252c] focus:bg-[#1f2b33] border border-white/10 focus:border-[#2fd9f4]/50 rounded-2xl text-sm font-semibold text-white placeholder-[#bbc9cd]/40 focus:outline-none focus:ring-2 focus:ring-[#2fd9f4]/15 transition-all text-center"
              maxLength={20}
              required
            />
          </div>

          {error && (
            <p className="text-[11px] text-red-400 font-medium text-left px-2 animate-pulse">
              ⚠️ {error}
            </p>
          )}

          <button
            id="login-submit-btn"
            type="submit"
            className="w-full py-4 rounded-2xl bg-[#8aebff] hover:bg-[#2fd9f4] active:scale-[0.98] text-[#00363e] font-bold text-xs uppercase tracking-widest shadow-[0_8px_20px_rgba(47,217,244,0.15)] hover:shadow-[0_8px_25px_rgba(47,217,244,0.25)] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            Träume online abrufen
            <ArrowRight className="w-4 h-4 text-[#00363e]" />
          </button>
        </form>

        <div className="mt-6 flex items-center justify-center gap-2 text-[10px] text-emerald-400 font-semibold uppercase tracking-wider bg-emerald-500/5 py-2 px-4 rounded-lg border border-emerald-500/10">
          <CloudCheck className="w-3.5 h-3.5" />
          <span>Echtzeit-Synchronisierung aktiv</span>
        </div>
      </div>

      {/* Footer Info */}
      <div className="pb-6 relative z-10 max-w-xs mx-auto text-[10px] text-[#bbc9cd]/40 flex items-center justify-center gap-1.5">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-500/60" />
        Sichere Online-Traumdatenbank ✓
      </div>

    </div>
  );
}
