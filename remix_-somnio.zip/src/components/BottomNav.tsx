/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Home, FileText, LineChart, GraduationCap } from "lucide-react";

interface BottomNavProps {
  activeTab: "home" | "journal" | "analysis" | "course";
  onTabChange: (tab: "home" | "journal" | "analysis" | "course") => void;
}

export default function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const navItems = [
    { id: "home" as const, label: "Home", icon: Home },
    { id: "journal" as const, label: "Journal", icon: FileText },
    { id: "analysis" as const, label: "Analytics", icon: LineChart },
    { id: "course" as const, label: "Course", icon: GraduationCap },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 rounded-t-xl bg-[#0e141a]/40 backdrop-blur-lg border-t border-white/10 shadow-[0_-4px_24px_rgba(34,211,238,0.1)]">
      <div className="flex justify-around items-center h-20 px-4 pb-safe max-w-[600px] mx-auto w-full">
        {navItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              id={`nav-tab-${item.id}`}
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center flex-1 py-2 active:scale-90 transition-transform duration-150 ${
                isActive
                  ? "text-[#2fd9f4] font-semibold"
                  : "text-[#bbc9cd]/60 hover:text-[#2fd9f4] transition-colors"
              }`}
            >
              <IconComponent
                className="w-6 h-6 mb-1"
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span className="font-label-sm text-[11px] tracking-tight">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
