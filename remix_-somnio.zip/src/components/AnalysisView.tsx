/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Sparkles, Smile, Landmark, Key, UserCheck, Heart, Tag, Lightbulb, Calendar, RefreshCw, FileCheck } from "lucide-react";
import { DreamAnalysis } from "../types";

interface AnalysisViewProps {
  analysis: DreamAnalysis;
  dateStr: string;
  isSaved: boolean;
  onSave: () => void;
  onClose?: () => void;
}

export default function AnalysisView({
  analysis,
  dateStr,
  isSaved,
  onSave,
  onClose,
}: AnalysisViewProps) {
  const { title, analysis: bodyText, lucidityScoreEstimate, isLucid, interpretation, emotions, symbols, dreamSigns } = analysis;

  // --- PLUTCHIK EMOTIONS SCORING ALGORITHM ---
  // 1. Filter out 0% intensities
  // 2. Sort descending
  // 3. Keep top 4
  const plutchikList = Object.entries(emotions || {})
    .map(([name, val]) => {
      // Capitalize first letter for German display name
      const displayName = name.charAt(0).toUpperCase() + name.slice(1);
      return { name: displayName, rawKey: name, value: val };
    })
    .filter((e) => e.value > 0) // Activity check: 0% completely excluded
    .sort((a, b) => b.value - a.value); // Descending sort

  const topEmotions = plutchikList.slice(0, 4); // Top 4 Focus (Trimm-Algorithmus)

  // Decide circular emoji according to the dominant emotion
  const getSentimentLabel = () => {
    if (lucidityScoreEstimate >= 8) return "Hyper-Klar & Grenzenlos";
    if (topEmotions.length === 0) return "Ausgeglichener Ruhezustand";
    const top = topEmotions[0];
    if (top.rawKey === "freude") return "Sehr positiv & befreiend";
    if (top.rawKey === "angst") return "Konfrontativ & intensiv";
    if (top.rawKey === "traurigkeit") return "Melancholisch-nachdenklich";
    if (top.rawKey === "wut") return "Konfliktgeladen & aufgewühlt";
    if (top.rawKey === "vertrauen") return "Tief beruhigend & sicher";
    if (top.rawKey === "ueberraschung") return "Erstaunlich & faszinierend";
    return "Emotional aufgeladen";
  };

  return (
    <div className="w-full text-[#dde3eb] animate-fade-in pb-16">
      {/* Header Info */}
      <section className="mb-8">
        <div className="flex flex-col gap-2">
          <span className="font-label-md text-xs text-[#2fd9f4] uppercase tracking-widest font-semibold block">
            Traum-Analyse
          </span>
          <h2 className="font-headline-lg-mobile md:font-headline-lg text-2xl md:text-3.5xl font-bold tracking-tight text-on-surface">
            {title || "Der Ruf des Leuchtturms"}
          </h2>
          <div className="flex items-center gap-2 text-[#bbc9cd]/60 text-xs">
            <Calendar className="w-3.5 h-3.5" />
            <span className="font-label-sm uppercase">
              {dateStr || "24. OKTOBER 2023 • 04:12 UHR"}
            </span>
          </div>
        </div>
      </section>

      {/* Main Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        
        {/* LEFT COLUMN: Summary & Abstract Visual (8 cols) */}
        <div className="md:col-span-8 flex flex-col gap-6">
          
          {/* Summary Card */}
          <div className="bg-[#242b31]/40 backdrop-blur-md p-6 rounded-xl relative overflow-hidden group border border-white/10">
            <div className="absolute top-0 left-0 w-1 h-full bg-[#8aebff]/40"></div>
            <div className="flex items-center gap-3 mb-4">
              <Sparkles className="w-5 h-5 text-[#8aebff]" />
              <h3 className="font-headline-md text-lg md:text-xl font-bold text-on-surface">
                KI-Zusammenfassung
              </h3>
            </div>
            <p className="text-[#bbc9cd] leading-relaxed text-sm md:text-base whitespace-pre-line">
              {bodyText}
            </p>
          </div>

          {/* Ethereal Dream Image Card */}
          <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-[#1a2026]/40 backdrop-blur-md border border-[#2fd9f4] shadow-[0_0_15px_rgba(47,217,244,0.15)] group cursor-crosshair">
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center pointer-events-none p-6 text-center">
              <div className="bg-[#0e141a]/60 backdrop-blur-md px-6 py-4 rounded-xl border border-white/5">
                <Sparkles className="w-8 h-8 text-[#8aebff] mx-auto mb-2 opacity-80 animate-pulse" />
                <p className="font-label-md text-xs text-[#8aebff]/80 font-bold uppercase tracking-widest">
                  Stimmungsbild des Unterbewusstseins
                </p>
              </div>
            </div>

            {/* Generated visual representational canvas */}
            <div className="absolute inset-0 transition-transform duration-1000 group-hover:scale-105">
              <img
                src={analysis.imageUrl || "https://images.unsplash.com/photo-1518531933037-91b2f5f229cc?auto=format&fit=crop&w=800&q=80"}
                alt={title || "Stimmungsbild des Unterbewusstseins"}
                className="w-full h-full object-cover opacity-75"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Star Overlay effect */}
            <div className="absolute inset-0 opacity-20 pointer-events-none mix-blend-overlay bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.15)_0,transparent_100%)]"></div>
          </div>
        </div>

        {/* RIGHT COLUMN: Indicators, Sentiment & Plutchik (4 cols) */}
        <div className="md:col-span-4 flex flex-col gap-6">
          
          {/* Sentiment Gauge */}
          <div className="bg-[#242b31]/40 backdrop-blur-md p-6 rounded-xl flex flex-col items-center text-center border border-white/10">
            <span className="font-label-sm text-[10px] text-[#bbc9cd]/60 tracking-widest uppercase mb-4">
              Sentiment
            </span>
            <div className="w-24 h-24 rounded-full border-4 border-[#8aebff]/10 flex items-center justify-center relative mb-4">
              <div className="absolute inset-0 rounded-full border-t-4 border-[#8aebff] animate-spin" style={{ animationDuration: "5s" }}></div>
              <Smile className="w-8 h-8 text-[#2fd9f4]" />
            </div>
            <p className="font-headline-md text-lg font-bold text-[#8aebff]">
              {getSentimentLabel()}
            </p>
          </div>

          {/* Plutchik Emotional Matrix panel */}
          <div className="bg-[#242b31]/40 backdrop-blur-md p-6 rounded-xl border border-white/10">
            <h4 className="font-label-md text-xs text-[#bbc9cd] font-bold uppercase mb-4 flex items-center gap-1.5">
              <Heart className="w-4 h-4 text-[#ddb8ff]" /> Emotionale Analyse
            </h4>
            
            {topEmotions.length === 0 ? (
              <p className="text-xs text-[#bbc9cd]/50 italic">
                Keine meßbaren Gefühlstiefe in dieser Traumfaser.
              </p>
            ) : (
              <div className="flex flex-col gap-4">
                {topEmotions.map((item) => {
                  // Determine secondary vs primary colors for gauge
                  const isPrimary = ["freude", "vertrauen", "erwartung"].includes(item.rawKey);
                  return (
                    <div key={item.name} className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#bbc9cd] font-medium">{item.name}</span>
                        <span className={isPrimary ? "text-[#8aebff]" : "text-[#ddb8ff]"}>
                          {item.value}%
                        </span>
                      </div>
                      <div className="w-full bg-[#2f353c] h-1.5 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-1000 ${
                            isPrimary ? "bg-[#8aebff]" : "bg-[#ddb8ff]"
                          }`}
                          style={{ width: `${item.value}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Micro pills badges */}
            {topEmotions.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-1.5">
                {topEmotions.map((item) => (
                  <span
                    key={item.name}
                    className="px-2.5 py-1 rounded-full bg-[#8aebff]/10 border border-[#8aebff]/15 text-[#8aebff] text-[9px] font-bold uppercase"
                  >
                    {item.name} {item.value}%
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Cleaned Keywords and symbol signs */}
          <div className="bg-[#242b31]/40 backdrop-blur-md p-6 rounded-xl border border-white/10">
            <h4 className="font-label-md text-xs text-[#bbc9cd] font-bold uppercase mb-4 flex items-center gap-1.5">
              <Tag className="w-4 h-4 text-[#2fd9f4]" /> Keywords
            </h4>
            <div className="flex flex-wrap gap-2">
              {/* Render dynamic keyword chips cleaned recursively by codex */}
              {dreamSigns && dreamSigns.length > 0 ? (
                dreamSigns.map((ds) => (
                  <span
                    key={ds}
                    className="px-3 py-1.5 bg-[#1a2026]/40 border border-white/10 rounded-lg text-xs leading-none text-[#dde3eb]"
                  >
                    {ds}
                  </span>
                ))
              ) : (
                <span className="text-xs text-[#bbc9cd]/40 italic">
                  Keine extrahierten Ankerwörter vorhanden.
                </span>
              )}
            </div>
          </div>
        </div>

        {/* BOTTOM: Expanded Symbolic Interpretation section (12 cols) */}
        <div className="md:col-span-12">
          <div className="bg-[#242b31]/40 backdrop-blur-md p-6 md:p-8 rounded-xl flex flex-col md:flex-row items-center gap-6 border border-white/10">
            <div className="w-16 h-16 shrink-0 bg-[#bfbbf5]/10 rounded-full flex items-center justify-center text-[#ddd9ff] border border-white/5 shadow-inner">
              <Lightbulb className="w-8 h-8 text-[#ddd9ff]" />
            </div>
            <div className="flex-1 w-full text-center md:text-left">
              <h4 className="font-headline-md text-xl font-bold mb-2 text-on-surface">
                Symbolische Deutung
              </h4>
              <p className="text-[#bbc9cd] text-sm md:text-base leading-relaxed">
                <span className="text-[#8aebff] font-semibold">
                  {symbols?.objects?.[0]?.name || symbols?.locations?.[0]?.name || title}
                </span>{" "}
                {interpretation?.meaning || "Dieses Traummotiv drängt auf bewusste Reorganisation deines kognitiven Schutzraums."}{" "}
                <span className="text-[#ddb8ff] font-medium block mt-2">
                  Praktische Übung: {interpretation?.recommendation || "Führe reality checks durch."}
                </span>
              </p>
            </div>
          </div>
        </div>

        {/* BOTTOM EXTRA: Detailed Catalog of symbols (Characters, Locations, Objects) */}
        <div className="md:col-span-12 grid grid-cols-1 md:grid-cols-3 gap-6 mt-2">
          {/* Characters */}
          <div className="bg-[#1a2026]/30 rounded-xl p-5 border border-white/5">
            <h5 className="text-xs font-bold text-[#bbc9cd] uppercase mb-3 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5" /> Archetypische Figuren ({symbols?.characters?.length || 0})
            </h5>
            <div className="space-y-2">
              {symbols?.characters && symbols.characters.length > 0 ? (
                symbols.characters.map((sc, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm bg-[#1a2026]/40 p-2 rounded-lg border border-white/5">
                    <span className="text-lg">{sc.emoji || "👤"}</span>
                    <span className="font-medium text-[#dde3eb]">{sc.name}</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[#bbc9cd]/40 italic">Keine Figuren erkannt.</p>
              )}
            </div>
          </div>

          {/* Locations */}
          <div className="bg-[#1a2026]/30 rounded-xl p-5 border border-white/5">
            <h5 className="text-xs font-bold text-[#bbc9cd] uppercase mb-3 flex items-center gap-1">
              <Landmark className="w-3.5 h-3.5" /> Seelenlandschaften ({symbols?.locations?.length || 0})
            </h5>
            <div className="space-y-2">
              {symbols?.locations && symbols.locations.length > 0 ? (
                symbols.locations.map((sl, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm bg-[#1a2026]/40 p-2 rounded-lg border border-white/5">
                    <span className="text-lg">{sl.emoji || "📍"}</span>
                    <span className="font-medium text-[#dde3eb]">{sl.name}</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[#bbc9cd]/40 italic">Keine Landschaften erkannt.</p>
              )}
            </div>
          </div>

          {/* Objects */}
          <div className="bg-[#1a2026]/30 rounded-xl p-5 border border-white/5">
            <h5 className="text-xs font-bold text-[#bbc9cd] uppercase mb-3 flex items-center gap-1">
              <Key className="w-3.5 h-3.5" /> Fokusobjekte ({symbols?.objects?.length || 0})
            </h5>
            <div className="space-y-2">
              {symbols?.objects && symbols.objects.length > 0 ? (
                symbols.objects.map((so, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm bg-[#1a2026]/40 p-2 rounded-lg border border-white/5">
                    <span className="text-lg">{so.emoji || "🔑"}</span>
                    <span className="font-medium text-[#dde3eb]">{so.name}</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-[#bbc9cd]/40 italic">Keine Objekte erkannt.</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Main Bottom save action button */}
      <div className="mt-12 flex flex-col md:flex-row items-center justify-center gap-4">
        <button
          id="save-to-journal-btn"
          onClick={onSave}
          className={`px-10 py-4 rounded-full font-bold shadow-[0_0_24px_rgba(47,217,244,0.3)] hover:scale-105 active:scale-95 transition-all duration-300 flex items-center gap-2 cursor-pointer ${
            isSaved
              ? "bg-gradient-to-r from-teal-500/30 to-emerald-500/30 text-emerald-300 border border-emerald-500/30 shadow-none hover:scale-100 cursor-default"
              : "bg-gradient-to-r from-[#8aebff] to-[#ddb8ff] text-[#00363e]"
          }`}
        >
          {isSaved ? (
            <>
              <FileCheck className="w-5 h-5 text-emerald-400" />
              Erfolgreich im Journal gesichert
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Im Journal speichern
            </>
          )}
        </button>

        {onClose && (
          <button
            id="analysis-close-btn"
            onClick={onClose}
            className="px-8 py-4 rounded-full bg-white/5 border border-white/10 hover:bg-white/10 text-[#bbc9cd] hover:text-[#2fd9f4] text-sm font-semibold tracking-wide cursor-pointer active:scale-95 transition-all duration-200"
          >
            Zurück zur Übersicht
          </button>
        )}
      </div>
    </div>
  );
}
