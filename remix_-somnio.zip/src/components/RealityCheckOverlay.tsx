/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Compass, Sparkles, Fingerprint, Eye, ArrowRight, ShieldCheck } from "lucide-react";

interface RealityCheckOverlayProps {
  onComplete: () => void;
}

export default function RealityCheckOverlay({ onComplete }: RealityCheckOverlayProps) {
  const [seconds, setSeconds] = useState(5);
  const [currentTip, setCurrentTip] = useState(0);

  const tips = [
    {
      action: "Nase zuhalten",
      details: "Halte deine Nase zu & versuche zu atmen. Gelingt es dir? Dann träumst du gerade!",
      color: "text-[#8aebff]"
    },
    {
      action: "Hand-Check",
      details: "Zähle deine Finger einzeln ab. Sind es genau fünf? Verschwimmen die Linien?",
      color: "text-[#ddb8ff]"
    },
    {
      action: "Uhren-Test",
      details: "Schau auf eine Uhr, blicke weg und schaue erneut hin. Stehen noch dieselben Zahlen da?",
      color: "text-[#2fd9f4]"
    }
  ];

  useEffect(() => {
    // Stagger / rotate tips every 1.8 seconds to keep it fully dynamic
    const tipInterval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length);
    }, 1800);

    return () => clearInterval(tipInterval);
  }, []);

  useEffect(() => {
    if (seconds <= 0) {
      const timeout = setTimeout(() => {
        onComplete();
      }, 500); // minor smooth finish delay
      return () => clearTimeout(timeout);
    }

    const timer = setInterval(() => {
      setSeconds((prev) => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [seconds, onComplete]);

  return (
    <div className="fixed inset-0 z-[200] bg-[#090d11] flex flex-col justify-between p-8 text-center overflow-hidden">
      
      {/* Space aurora backgrounds */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#8aebff]/10 blur-[130px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-1/4 left-1/2 -translate-x-1/2 translate-y-1/2 w-80 h-80 bg-[#ddb8ff]/5 blur-[120px] rounded-full pointer-events-none"></div>

      {/* Header section info */}
      <div className="relative pt-6 flex flex-col items-center gap-1.5 z-10">
        <div className="flex items-center gap-2 px-3 py-1 bg-white/5 border border-white/10 rounded-full">
          <Compass className="w-4 h-4 text-[#8aebff] animate-spin" style={{ animationDuration: "10s" }} />
          <span className="font-mono text-[9px] uppercase tracking-widest text-[#bbc9cd]">
            Somnio Core-Sitzung
          </span>
        </div>
      </div>

      {/* Core Center Countdown Circle area */}
      <div className="relative flex flex-col items-center justify-center py-10 z-10">
        
        {/* Pulsating glowing halo orbits */}
        <div className="absolute w-52 h-52 border border-[#2fd9f4]/15 rounded-full animate-ping pointer-events-none"></div>
        <div className="absolute w-44 h-44 bg-[#8aebff]/5 rounded-full blur-md animate-pulse"></div>

        {/* Circular Dial display */}
        <div className="w-36 h-36 rounded-full border-2 border-white/5 bg-[#12181e]/40 backdrop-blur-md flex flex-col items-center justify-center relative shadow-[0_0_40px_rgba(47,217,244,0.08)]">
          <span className="font-sans text-[72px] font-thin leading-none tracking-tighter text-[#2fd9f4] drop-shadow-[0_0_12px_rgba(47,217,244,0.3)] select-none">
            {seconds > 0 ? seconds : <Eye className="w-14 h-14 text-[#8aebff] animate-pulse" />}
          </span>
          <span className="text-[10px] uppercase font-bold tracking-widest text-[#bbc9cd]/60 mt-1">
            {seconds > 0 ? "Sekunden" : "Bereit!"}
          </span>
        </div>

        {/* Reality check Title banner statement */}
        <div className="mt-8 space-y-2 max-w-sm">
          <h2 className="font-display text-4xl font-bold tracking-tight text-white">
            Realitätscheck
          </h2>
          <p className="text-xs text-[#bbc9cd]/70 uppercase tracking-widest font-mono font-semibold">
            Bist du wach oder träumst du?
          </p>
        </div>

        {/* Interactive Dynamic Coach card tip */}
        <div className="mt-8 px-6 py-4 bg-[#141b21]/70 border border-white/5 rounded-2xl max-w-sm w-full shadow-inner animate-fade-in relative min-h-[96px] flex flex-col justify-center">
          <span className={`text-[11px] font-bold uppercase tracking-wider block mb-1 ${tips[currentTip].color} transition-colors duration-500`}>
            {tips[currentTip].action}
          </span>
          <p className="text-xs text-[#dde3eb] leading-relaxed transition-opacity duration-300">
            {tips[currentTip].details}
          </p>
        </div>
      </div>

      {/* Lower footer trigger actions */}
      <div className="relative pb-6 flex flex-col items-center gap-3 z-10 w-full max-w-xs mx-auto">
        <button
          id="skip-countdown-btn"
          onClick={onComplete}
          className="px-6 py-2.5 rounded-full bg-white/5 hover:bg-white/10 text-[#bbc9cd] hover:text-[#2fd9f4] text-xs font-semibold tracking-wide transition-all duration-300 flex items-center gap-1.5 cursor-pointer"
        >
          Auslassen <ArrowRight className="w-3.5 h-3.5" />
        </button>
        
        <p className="text-[10px] text-[#bbc9cd]/40 flex items-center gap-1.5 justify-center">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500/60" />
          Tägliches Klartraum-Klarheitstraining
        </p>
      </div>

    </div>
  );
}
