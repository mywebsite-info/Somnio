/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Mic, Image as ImageIcon, Clock, Lock, Sparkles, Loader } from "lucide-react";

interface EditorProps {
  onAnalyze: (payload: {
    text: string;
    clarity: "Trüb" | "Mittel" | "Luzide";
    mood: "Glücklich" | "Ängstlich" | "Neutral";
  }) => void;
  isLoading: boolean;
}

export default function Editor({ onAnalyze, isLoading }: EditorProps) {
  const [text, setText] = useState("");
  const [clarity, setClarity] = useState<"Trüb" | "Mittel" | "Luzide">("Mittel");
  const [mood, setMood] = useState<"Glücklich" | "Ängstlich" | "Neutral">("Neutral");
  const [saveTime, setSaveTime] = useState("");

  // Loading messages rotation
  const [loadingMsgIdx, setLoadingMsgIdx] = useState(0);
  const loadingMessages = [
    "Analysiere Traumsymbole im quanten-linguistischen Takt...",
    "Rufe psychoanalytische Archetypen der Jungschen Lehre ab...",
    "Ermittle emotionale Gewichtungsmatrix nach Robert Plutchik...",
    "Berechne prädiktive Schlafphasen & REM-Peak-Intervalle...",
    "Verschlüssele Erkenntnisse für dein persönliches Journal..."
  ];

  useEffect(() => {
    // Generate a reasonable timestamp on load
    const now = new Date();
    const hrs = String(now.getHours()).padStart(2, "0");
    const mins = String(now.getMinutes()).padStart(2, "0");
    setSaveTime(`${hrs}:${mins}`);
  }, []);

  // Update loading message progressively
  useEffect(() => {
    let interval: any;
    if (isLoading) {
      interval = setInterval(() => {
        setLoadingMsgIdx((prev) => (prev + 1) % loadingMessages.length);
      }, 4000);
    } else {
      setLoadingMsgIdx(0);
    }
    return () => clearInterval(interval);
  }, [isLoading]);

  // Insert current timestamp into editor as a helper micro-interaction
  const handleInsertTimestamp = () => {
    const now = new Date();
    const timeStr = `[${now.toLocaleTimeString("de-DE", { hour: '2-digit', minute: '2-digit' })} Uhr]: `;
    setText((p) => timeStr + p);
  };

  // Safe preset triggers helper
  const handleInsertExample = () => {
    setText(
      "In meinem Traum lief ich barfuß durch einen neonleuchtenden Kristallpalast. Plötzlich wuchsen mir riesige, aquamarinblaue Flügel, und ich schwang mich über einen silbergrauen Ozean empor. Ein schwebender Leuchtturm wies mir den Weg bis an den kosmischen Horizont."
    );
    setClarity("Luzide");
    setMood("Glücklich");
  };

  const handleAnalyzeClick = () => {
    if (!text.trim()) return;
    onAnalyze({ text, clarity, mood });
  };

  return (
    <div className="w-full text-[#dde3eb]">
      {/* Header Info */}
      <div className="flex flex-col gap-2 mb-8 text-center md:text-left">
        <p className="font-label-md text-xs text-[#8aebff] uppercase tracking-widest font-semibold block">
          Heute Nacht
        </p>
        <h2 className="font-display-lg text-3xl md:text-4xl text-on-surface font-bold tracking-tight">
          Was hast du geträumt?
        </h2>
      </div>

      {isLoading ? (
        /* Dynamic Loading Screen with astral animation */
        <div className="flex flex-col items-center justify-center min-h-[400px] text-center p-8 bg-[#1a2026]/40 border border-white/10 rounded-xl relative overflow-hidden">
          <div className="absolute inset-0 bg-transparent overflow-hidden pointer-events-none">
            <div className="absolute top-1/4 left-1/4 w-32 h-32 bg-[#8aebff]/10 blur-[60px] rounded-full animate-pulse"></div>
            <div className="absolute bottom-1/4 right-1/4 w-32 h-32 bg-[#ddb8ff]/10 blur-[60px] rounded-full animate-pulse"></div>
          </div>
          
          <div className="relative mb-6">
            <div className="w-18 h-18 rounded-full border-2 border-[#2fd9f4]/20 flex items-center justify-center">
              <Loader className="w-10 h-10 text-[#2fd9f4] animate-spin" />
            </div>
          </div>

          <p className="font-headline-md text-xl text-[#2fd9f4] mb-3">
            Astraler Transfer...
          </p>
          <p className="max-w-md text-sm text-[#bbc9cd] animate-fade-in-out h-12 leading-relaxed">
            {loadingMessages[loadingMsgIdx]}
          </p>
        </div>
      ) : (
        /* Working Editor view */
        <div className="flex flex-col gap-6">
          {/* Main text container */}
          <div
            className={`bg-[#242b31]/40 backdrop-blur-md rounded-xl p-6 min-h-[360px] flex flex-col transition-all duration-500 border ${
              clarity === "Luzide"
                ? "border-[#2fd9f4] shadow-[0_0_15px_rgba(47,217,244,0.15)]"
                : "border-white/10 focus-within:border-[#2fd9f4]"
            }`}
          >
            <textarea
              id="dream-editor-textarea"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="flex-grow bg-transparent border-none text-base md:text-lg focus:outline-none focus:ring-0 text-[#dde3eb] placeholder-[#bbc9cd]/30 custom-scrollbar resize-none w-full min-h-[220px]"
              placeholder="Erzähl mir alles von deinem Traum... Symbole, Gefühle, Personen..."
            />

            {/* Micro-interaction Toolbar */}
            <div className="mt-4 pt-4 border-t border-white/5 flex flex-wrap items-center justify-between gap-4">
              <div className="flex gap-1">
                <button
                  id="editor-btn-mic"
                  onClick={() => alert("Sprachaufnahme-Modul erfordert ein externes Mikrofon. Trage Freitext direkt ein.")}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/5 text-[#bbc9cd] hover:text-[#2fd9f4] transition-colors"
                  title="Sprachaufnahme"
                >
                  <Mic className="w-4 h-4" />
                </button>
                <button
                  id="editor-btn-img"
                  onClick={() => {
                    const confirmUse = window.confirm("Möchtest du eine magische Demo-Traumvorlage einspielen?");
                    if (confirmUse) handleInsertExample();
                  }}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/5 text-[#bbc9cd] hover:text-[#2fd9f4] transition-colors"
                  title="Kristallpalast Traumvorlage einspielen"
                >
                  <ImageIcon className="w-4 h-4" />
                </button>
                <button
                  id="editor-btn-time"
                  onClick={handleInsertTimestamp}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-white/5 text-[#bbc9cd] hover:text-[#2fd9f4] transition-colors"
                  title="Aktuellen Zeitstempel"
                >
                  <Clock className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-[#bbc9cd]/40">
                Zuletzt gespeichert um {saveTime} Uhr
              </p>
            </div>
          </div>

          {/* Metadata Selection Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Clarity Chips */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-[#bbc9cd]/80 uppercase px-1 flex items-center gap-1.5">
                Klarheitsgrad
              </label>
              <div className="flex flex-wrap gap-2">
                {(["Trüb", "Mittel", "Luzide"] as const).map((lvl) => {
                  const active = clarity === lvl;
                  return (
                    <button
                      id={`chip-clarity-${lvl}`}
                      key={lvl}
                      type="button"
                      onClick={() => setClarity(lvl)}
                      className={`px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                        active
                          ? "bg-[#2fd9f4]/20 text-[#2fd9f4] border border-[#2fd9f4]/50 shadow-[0_0_8px_rgba(47,217,244,0.3)]"
                          : "bg-[#1a2026]/40 border border-white/10 text-[#bbc9cd] hover:border-[#8aebff]/30"
                      }`}
                    >
                      {lvl}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Mood Chips */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-semibold text-[#bbc9cd]/80 uppercase px-1 flex items-center gap-1.5">
                Grundstimmung
              </label>
              <div className="flex flex-wrap gap-2">
                {(["Glücklich", "Ängstlich", "Neutral"] as const).map((m) => {
                  const active = mood === m;
                  return (
                    <button
                      id={`chip-mood-${m}`}
                      key={m}
                      type="button"
                      onClick={() => setMood(m)}
                      className={`px-4 py-2 rounded-full text-xs font-semibold transition-all cursor-pointer ${
                        active
                          ? "bg-[#ddb8ff]/20 text-[#ddb8ff] border border-[#ddb8ff]/50 shadow-[0_0_8px_rgba(221,184,255,0.3)]"
                          : "bg-[#1a2026]/40 border border-white/10 text-[#bbc9cd] hover:border-[#ddb8ff]/30"
                      }`}
                    >
                      {m}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Action Trigger */}
          <div className="mt-4 flex flex-col items-center">
            <button
              id="analyze-submit-btn"
              disabled={!text.trim()}
              onClick={handleAnalyzeClick}
              className={`group relative px-12 py-4 rounded-full bg-gradient-to-r from-[#8aebff] to-[#ddb8ff] text-[#00363e] font-bold text-base transition-all duration-300 shadow-[0_0_24px_rgba(34,211,238,0.25)] hover:scale-105 active:scale-95 flex items-center gap-2 cursor-pointer ${
                !text.trim() ? "opacity-50 cursor-not-allowed hover:scale-100" : ""
              }`}
            >
              Traum analysieren
              <Sparkles className="w-5 h-5 text-[#00363e] animate-pulse group-hover:translate-x-1 transition-transform" />
            </button>
            <p className="mt-3 text-xs text-[#bbc9cd]/60 flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-[#bbc9cd]/40" />
              Privat & Ende-zu-Ende verschlüsselt
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
