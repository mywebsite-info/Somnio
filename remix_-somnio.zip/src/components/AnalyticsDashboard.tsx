/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Sparkles, Heart, Tag, Landmark, Key, UserCheck, BarChart3, Activity, Compass, Zap } from "lucide-react";
import { DreamEntry } from "../types";

interface AnalyticsDashboardProps {
  entries: DreamEntry[];
}

export default function AnalyticsDashboard({ entries }: AnalyticsDashboardProps) {
  if (entries.length === 0) {
    return (
      <div className="w-full text-center py-16 px-6 bg-[#1a2026]/20 border border-dashed border-white/10 rounded-2xl">
        <BarChart3 className="w-12 h-12 text-[#2fd9f4]/40 mx-auto mb-4 animate-pulse" />
        <h3 className="text-lg font-bold text-[#dde3eb] mb-2 font-display">
          Keine Analytics verfügbar
        </h3>
        <p className="text-xs text-[#bbc9cd]/60 max-w-md mx-auto">
          Zeichne deine ersten Träume im Journal auf, um tiefe unbewusste Muster freizuschalten.
        </p>
      </div>
    );
  }

  const totalCount = entries.length;

  // 1. Emotion Aggregation
  const emotionSums: Record<string, number> = {
    freude: 0,
    vertrauen: 0,
    angst: 0,
    ueberraschung: 0,
    traurigkeit: 0,
    ekel: 0,
    wut: 0,
    erwartung: 0,
  };

  entries.forEach((e) => {
    const ems = e.analysis?.emotions;
    if (ems) {
      Object.keys(emotionSums).forEach((k) => {
        if (typeof ems[k as keyof typeof ems] === "number") {
          emotionSums[k] += ems[k as keyof typeof ems] || 0;
        }
      });
    }
  });

  const emotionAverages = Object.entries(emotionSums)
    .map(([key, sum]) => {
      const displayName = key.charAt(0).toUpperCase() + key.slice(1);
      return {
        rawKey: key,
        displayName,
        percentage: Math.round(sum / totalCount),
      };
    })
    .sort((a, b) => b.percentage - a.percentage);

  // 2. Archetypes Aggregates
  const charactersMap: Record<string, { count: number; emoji: string }> = {};
  const locationsMap: Record<string, { count: number; emoji: string }> = {};
  const objectsMap: Record<string, { count: number; emoji: string }> = {};
  const keywordsMap: Record<string, number> = {};

  entries.forEach((e) => {
    const symbols = e.analysis?.symbols;
    if (symbols) {
      symbols.characters?.forEach((c) => {
        if (!c.name) return;
        const normalized = c.name.trim();
        if (!charactersMap[normalized]) {
          charactersMap[normalized] = { count: 0, emoji: c.emoji || "👤" };
        }
        charactersMap[normalized].count++;
      });

      symbols.locations?.forEach((l) => {
        if (!l.name) return;
        const normalized = l.name.trim();
        if (!locationsMap[normalized]) {
          locationsMap[normalized] = { count: 0, emoji: l.emoji || "📍" };
        }
        locationsMap[normalized].count++;
      });

      symbols.objects?.forEach((o) => {
        if (!o.name) return;
        const normalized = o.name.trim();
        if (!objectsMap[normalized]) {
          objectsMap[normalized] = { count: 0, emoji: o.emoji || "🔑" };
        }
        objectsMap[normalized].count++;
      });
    }

    e.analysis?.dreamSigns?.forEach((ds) => {
      if (!ds) return;
      const normalized = ds.trim();
      keywordsMap[normalized] = (keywordsMap[normalized] || 0) + 1;
    });
  });

  const sortedCharacters = Object.entries(charactersMap)
    .map(([name, val]) => ({ name, ...val }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const sortedLocations = Object.entries(locationsMap)
    .map(([name, val]) => ({ name, ...val }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const sortedObjects = Object.entries(objectsMap)
    .map(([name, val]) => ({ name, ...val }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  const sortedKeywords = Object.entries(keywordsMap)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  const topEmotion = emotionAverages[0];
  const lucidDreamsCount = entries.filter((e) => e.isLucid).length;
  const lucidPercentage = Math.round((lucidDreamsCount / totalCount) * 100);

  return (
    <div className="w-full text-[#dde3eb] animate-fade-in space-y-6">
      {/* Header section with micro stats */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/5 pb-5">
        <div>
          <span className="text-[10px] text-[#2fd9f4] uppercase tracking-widest font-bold">
            STATISTIKEN & SYNTHeSE
          </span>
          <h2 className="text-2.5xl font-extrabold tracking-tight text-white font-display">
            Astrale Analyse
          </h2>
        </div>
        <div className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-lg border border-white/10 text-xs">
          <Activity className="w-3.5 h-3.5 text-[#2fd9f4] animate-pulse" />
          <span>Synchronisiert</span>
        </div>
      </div>

      {/* Bento Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Metric 1 */}
        <div className="bg-[#1f262d]/55 backdrop-blur-md p-4 rounded-xl border border-white/5 flex items-center justify-between">
          <div>
            <span className="text-[10px] tracking-wider text-[#bbc9cd]/60 uppercase block">Träume</span>
            <span className="text-2xl font-black text-white">{totalCount}</span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-[#2fd9f4]/10 flex items-center justify-center border border-[#2fd9f4]/20">
            <Compass className="w-5 h-5 text-[#2fd9f4]" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#1f262d]/55 backdrop-blur-md p-4 rounded-xl border border-white/5 flex items-center justify-between">
          <div>
            <span className="text-[10px] tracking-wider text-[#bbc9cd]/60 uppercase block">Klarheit</span>
            <span className="text-2xl font-black text-[#8aebff]">{lucidPercentage}%</span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-[#8aebff]/10 flex items-center justify-center border border-[#8aebff]/20">
            <Sparkles className="w-5 h-5 text-[#8aebff]" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#1f262d]/55 backdrop-blur-md p-4 rounded-xl border border-white/5 flex items-center justify-between">
          <div>
            <span className="text-[10px] tracking-wider text-[#bbc9cd]/60 uppercase block">Hauptaffekt</span>
            <span className="text-base font-bold text-[#ddb8ff] truncate max-w-[130px] block">
              {topEmotion?.displayName || "—"}
            </span>
          </div>
          <div className="w-10 h-10 rounded-lg bg-[#ddb8ff]/10 flex items-center justify-center border border-[#ddb8ff]/20">
            <Heart className="w-5 h-5 text-[#ddb8ff]" />
          </div>
        </div>
      </div>

      {/* Main Charts area */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
        
        {/* Emotions (7 cols) */}
        <div className="md:col-span-7 bg-[#1c2228]/50 p-5 rounded-xl border border-white/5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
              <Heart className="w-4 h-4 text-[#ddb8ff]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#ddb8ff]">Emotionale Intensität</h3>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
              {emotionAverages.slice(0, 6).map((item) => {
                const isPrimary = ["freude", "vertrauen", "erwartung"].includes(item.rawKey);
                return (
                  <div key={item.rawKey} className="space-y-1">
                    <div className="flex justify-between items-center text-[11px]">
                      <span className="text-[#bbc9cd] font-semibold">{item.displayName}</span>
                      <span className={isPrimary ? "text-[#8aebff] font-bold" : "text-[#ddb8ff] font-bold"}>
                        {item.percentage}%
                      </span>
                    </div>
                    <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          isPrimary 
                            ? "bg-gradient-to-r from-[#2fd9f4] to-[#8aebff]" 
                            : "bg-gradient-to-r from-[#bfbbf5] to-[#ddb8ff]"
                        }`}
                        style={{ width: `${item.percentage}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 p-3 rounded-lg bg-[#8aebff]/5 border border-white/5 text-[11px] text-[#bbc9cd] flex items-center gap-2">
            <Zap className="w-3.5 h-3.5 text-[#2fd9f4] shrink-0" />
            <span>
              Vorherrschend: <strong className="text-white font-semibold">{topEmotion?.displayName || "Stabil"}</strong> ({topEmotion?.percentage || 0}%).
            </span>
          </div>
        </div>

        {/* Dynamic Keywords (5 cols) */}
        <div className="md:col-span-5 bg-[#1c2228]/50 p-5 rounded-xl border border-white/5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-2">
              <Tag className="w-4 h-4 text-[#2fd9f4]" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#2fd9f4]">Schlüsselsignale</h3>
            </div>

            {sortedKeywords.length === 0 ? (
              <p className="text-[10px] text-[#bbc9cd]/40 italic py-6 text-center">Keine Traumsignale vorhanden</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {sortedKeywords.map((kw) => (
                  <div 
                    key={kw.name}
                    className="flex items-center gap-1 px-2.5 py-1 bg-white/5 border border-white/10 rounded-md text-[11px] text-[#dde3eb]"
                  >
                    <span className="text-[#8aebff] font-medium">{kw.name}</span>
                    <span className="bg-[#8aebff]/10 text-[#8aebff] rounded-sm text-[9px] px-1 font-bold">
                      {kw.count}x
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="text-[10px] text-[#bbc9cd]/50 italic pt-4">
            * Traum-Triggerpunkte deiner Psyche
          </div>
        </div>

      </div>

      {/* Archetypes grid with flat visual matrix (Characters, Locations, Objects) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        
        {/* Characters */}
        <div className="bg-[#1c2228]/45 rounded-xl p-4 border border-white/5">
          <div className="flex items-center gap-1.5 mb-3 pb-1.5 border-b border-white/5">
            <UserCheck className="w-3.5 h-3.5 text-[#8aebff]" />
            <h4 className="text-[10px] font-bold text-[#bbc9cd] uppercase tracking-wider">
              Archetypen
            </h4>
          </div>
          <div className="space-y-1.5">
            {sortedCharacters.length > 0 ? (
              sortedCharacters.map((char) => (
                <div key={char.name} className="flex justify-between items-center bg-white/5 px-2.5 py-1.5 rounded-lg border border-white/5 text-xs">
                  <span className="flex items-center gap-1.5 text-[#dde3eb]">
                    <span>{char.emoji}</span>
                    <span className="truncate max-w-[120px]">{char.name}</span>
                  </span>
                  <span className="text-[9px] text-[#bbc9cd]/60 font-bold">{char.count}x</span>
                </div>
              ))
            ) : (
              <p className="text-[10px] text-[#bbc9cd]/40 italic py-4 text-center">Keine erkannt.</p>
            )}
          </div>
        </div>

        {/* Landschaften */}
        <div className="bg-[#1c2228]/45 rounded-xl p-4 border border-white/5">
          <div className="flex items-center gap-1.5 mb-3 pb-1.5 border-b border-white/5">
            <Landmark className="w-3.5 h-3.5 text-[#ddb8ff]" />
            <h4 className="text-[10px] font-bold text-[#bbc9cd] uppercase tracking-wider">
              Landschaften
            </h4>
          </div>
          <div className="space-y-1.5">
            {sortedLocations.length > 0 ? (
              sortedLocations.map((loc) => (
                <div key={loc.name} className="flex justify-between items-center bg-white/5 px-2.5 py-1.5 rounded-lg border border-white/5 text-xs">
                  <span className="flex items-center gap-1.5 text-[#dde3eb]">
                    <span>{loc.emoji}</span>
                    <span className="truncate max-w-[120px]">{loc.name}</span>
                  </span>
                  <span className="text-[9px] text-[#bbc9cd]/60 font-bold">{loc.count}x</span>
                </div>
              ))
            ) : (
              <p className="text-[10px] text-[#bbc9cd]/40 italic py-4 text-center">Keine erkannt.</p>
            )}
          </div>
        </div>

        {/* Fokusobjekte */}
        <div className="bg-[#1c2228]/45 rounded-xl p-4 border border-white/5">
          <div className="flex items-center gap-1.5 mb-3 pb-1.5 border-b border-white/5">
            <Key className="w-3.5 h-3.5 text-[#2fd9f4]" />
            <h4 className="text-[10px] font-bold text-[#bbc9cd] uppercase tracking-wider">
              Schlüsselobjekte
            </h4>
          </div>
          <div className="space-y-1.5">
            {sortedObjects.length > 0 ? (
              sortedObjects.map((obj) => (
                <div key={obj.name} className="flex justify-between items-center bg-white/5 px-2.5 py-1.5 rounded-lg border border-white/5 text-xs">
                  <span className="flex items-center gap-1.5 text-[#dde3eb]">
                    <span>{obj.emoji}</span>
                    <span className="truncate max-w-[120px]">{obj.name}</span>
                  </span>
                  <span className="text-[9px] text-[#bbc9cd]/60 font-bold">{obj.count}x</span>
                </div>
              ))
            ) : (
              <p className="text-[10px] text-[#bbc9cd]/40 italic py-4 text-center">Keine erkannt.</p>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
