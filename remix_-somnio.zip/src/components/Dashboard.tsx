/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Moon, Sparkles, TrendingUp, Cloud, TreePine, Plus, Award, Trash2 } from "lucide-react";
import { DreamEntry } from "../types";

interface DashboardProps {
  entries: DreamEntry[];
  lucidityRate: number;
  lucidityTier: string;
  onNewDreamClick: () => void;
  onEntryClick: (entry: DreamEntry) => void;
  onDeleteEntry: (id: string) => void;
}

export default function Dashboard({
  entries,
  lucidityRate,
  lucidityTier,
  onNewDreamClick,
  onEntryClick,
  onDeleteEntry,
}: DashboardProps) {
  // Current active project metrics
  const activeCourseDay = 5;
  const activeCourseProgress = 35; // %

  // Count of dreams recorded this week
  const dreamsThisWeekCount = entries.filter((e) => {
    // Check if within 7 days
    try {
      const entryDate = new Date(e.rawDate);
      const diffTime = Math.abs(new Date().getTime() - entryDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays <= 7;
    } catch {
      return true;
    }
  }).length;

  return (
    <div className="w-full text-[#dde3eb]">
      {/* Welcome Section */}
      <section className="mb-8">
        <h2 className="font-display-lg text-display-lg text-[#8aebff] mb-2 font-bold tracking-tight">
          Guten Morgen, Träumer
        </h2>
        <p className="font-body-lg text-body-lg text-[#bbc9cd]">
          Bereit, deine Reise in das Unterbewusstsein fortzusetzen?
        </p>
      </section>

      {/* Progress Section (Aktuelles Projekt) */}
      <section className="mb-8">
        <div className="bg-[#1a2026]/40 backdrop-blur-md rounded-xl p-6 border border-white/10 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#8aebff] to-[#ddb8ff] opacity-10 blur-3xl rounded-full"></div>
          <div className="flex flex-col gap-4">
            <div className="flex justify-between items-end">
              <div>
                <span className="font-label-sm text-xs text-[#ddb8ff] uppercase tracking-widest block mb-1">
                  Aktuelles Projekt
                </span>
                <h3 className="font-headline-md text-xl md:text-2xl text-on-surface font-semibold">
                  Tag 5 von 14: Die MILD-Technik
                </h3>
              </div>
              <span className="font-label-md text-[#8aebff] font-bold">
                {activeCourseProgress}%
              </span>
            </div>
            <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#8aebff] to-[#ddb8ff] rounded-full shadow-[0_0_10px_rgba(47,217,244,0.5)] transition-all duration-1000"
                style={{ width: `${activeCourseProgress}%` }}
              ></div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Row */}
      <section className="grid grid-cols-2 gap-4 mb-8">
        <div className="bg-[#1a2026]/40 backdrop-blur-md rounded-xl p-5 flex flex-col gap-2 border border-white/10">
          <TrendingUp className="w-5 h-5 text-[#ddb8ff]" />
          <p className="font-label-sm text-xs text-[#bbc9cd] uppercase">
            Diese Woche
          </p>
          <p className="font-headline-md text-xl font-bold">
            {dreamsThisWeekCount} {dreamsThisWeekCount === 1 ? "Traum" : "Träume"}
          </p>
        </div>
        <div className="bg-[#1a2026]/40 backdrop-blur-md rounded-xl p-5 flex flex-col gap-2 border border-white/10 relative group">
          <Sparkles className="w-5 h-5 text-[#8aebff]" />
          <p className="font-label-sm text-xs text-[#bbc9cd] uppercase">
            Lucidity
          </p>
          <p className="font-headline-md text-xl font-bold">
            {Math.round(lucidityRate)}%
          </p>
          <span className="text-[10px] text-[#2fd9f4]/80 uppercase block tracking-wider font-semibold">
            {lucidityTier}
          </span>
        </div>
      </section>

      {/* Recent Dreams List */}
      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-headline-md text-xl text-on-surface font-semibold flex items-center gap-2">
            <Moon className="w-5 h-5 text-[#8aebff]" /> Letzte Träume
          </h3>
          <span className="text-xs text-[#bbc9cd]/60">
            {entries.length} gesamt
          </span>
        </div>

        {entries.length === 0 ? (
          <div className="text-center p-8 bg-[#1a2026]/20 border border-dashed border-white/10 rounded-xl">
            <p className="text-[#bbc9cd]/60 text-sm mb-4">
              Noch keine Träume aufgezeichnet.
            </p>
            <button
              onClick={onNewDreamClick}
              className="px-6 py-2.5 rounded-full bg-[#8aebff]/10 hover:bg-[#8aebff]/20 text-[#8aebff] border border-[#8aebff]/20 text-xs font-semibold tracking-wide"
            >
              Ersten Traum eintragen
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {entries.map((entry) => {
              const isLucid = entry.isLucid;
              // Check if entry text includes elements to choose best icon
              const txt = entry.text.toLowerCase();
              const isForest = txt.includes("wald") || txt.includes("baum") || txt.includes("natur");

              return (
                <div
                  id={`dream-card-${entry.id}`}
                  key={entry.id}
                  onClick={() => onEntryClick(entry)}
                  className={`bg-[#1a2026]/40 backdrop-blur-md rounded-xl p-5 group cursor-pointer hover:translate-y-[-2px] transition-all duration-300 ${
                    isLucid
                      ? "border border-[#2fd9f4] shadow-[0_0_15px_rgba(47,217,244,0.15)]"
                      : "border border-white/10"
                  }`}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="flex-1 min-w-0 pr-2">
                      <span
                        className={`font-label-sm text-[10px] uppercase tracking-tighter block mb-1 ${
                          isLucid ? "text-[#2fd9f4]" : "text-[#bbc9cd]/60"
                        }`}
                      >
                        {entry.date}
                      </span>
                      <h4 className="font-body-lg font-bold text-[#dde3eb] group-hover:text-[#2fd9f4] transition-colors truncate">
                        {entry.analysis?.title || "Unbetiteltes Traumerlebnis"}
                      </h4>
                    </div>
                    <div className="flex items-center gap-2.5 shrink-0">
                      {isLucid ? (
                        <Cloud className="w-5 h-5 text-[#2fd9f4]" />
                      ) : isForest ? (
                        <TreePine className="w-5 h-5 text-[#ddb8ff]" />
                      ) : (
                        <Moon className="w-5 h-5 text-[#bbc9cd]" />
                      )}
                      
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onDeleteEntry(entry.id);
                        }}
                        className="p-1.5 rounded-lg border border-rose-500/10 hover:bg-rose-500/15 text-rose-400 hover:text-rose-300 transition-colors cursor-pointer"
                        title="Eintrag löschen"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Symbol Tags */}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {isLucid && (
                      <span className="bg-[#8aebff]/10 border border-[#8aebff]/20 text-[#8aebff] px-2.5 py-0.5 rounded-full font-label-md text-[10px] uppercase font-bold tracking-wider">
                        LUZIDE
                      </span>
                    )}
                    {entry.analysis?.symbols?.objects?.slice(0, 2).map((obj) => (
                      <span
                        key={obj.name}
                        className="bg-white/5 border border-white/10 text-[#bbc9cd] px-2.5 py-0.5 rounded-full font-label-md text-[10px] uppercase"
                      >
                        {obj.emoji} {obj.name}
                      </span>
                    ))}
                    {!isLucid && entry.analysis?.dreamSigns?.slice(0, 2).map((sign) => (
                      <span
                        key={sign}
                        className="bg-white/5 border border-white/10 text-[#bbc9cd] px-2.5 py-0.5 rounded-full font-label-md text-[10px] uppercase"
                      >
                        {sign}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Pulsing circular FAB bottom right */}
      <button
        id="dashboard-fab-btn"
        onClick={onNewDreamClick}
        className="fixed bottom-24 right-6 w-14 h-14 rounded-full bg-gradient-to-r from-[#8aebff] to-[#ddb8ff] text-[#00363e] flex items-center justify-center shadow-[0_0_24px_rgba(34,211,238,0.4)] z-45 hover:scale-110 active:scale-95 transition-transform duration-200 cursor-pointer group animate-bounce"
        aria-label="Neue Aufzeichnung"
      >
        <Plus className="w-6 h-6 stroke-[3px] group-hover:rotate-90 transition-transform duration-300" />
      </button>
    </div>
  );
}
