/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Check, Lock, BookOpen, AlertCircle, Sparkles, Compass, Award } from "lucide-react";
import { CourseLesson } from "../types";

export default function CourseView() {
  const [progress, setProgress] = useState(25); // %
  const [isLessonOpen, setIsLessonOpen] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  // Lesson list representing timeline structure from screens
  const initialLessons: CourseLesson[] = [
    {
      id: "pre-prep",
      dayRange: "Tag 1-4",
      title: "Vorbereitung",
      description: "Grundlagen des Traumtagebuchs und Schlafhygiene wurden erfolgreich etabliert.",
      status: "completed",
      iconName: "check"
    },
    {
      id: "current-mild",
      dayRange: "Tag 5",
      title: "Reality Checks üben",
      description: "Lerne, wie du deinen Wachzustand im Alltag kritisch hinterfragst, um dieses Muster automatisch in deine Träume zu übertragen.",
      status: "active",
      iconName: "05"
    },
    {
      id: "locked-signs",
      dayRange: "Tag 6",
      title: "Traumzeichen erkennen",
      description: "Noch gesperrt. Verinnerliche zuerst die täglichen Reality-Checks von Tag 5.",
      status: "locked",
      iconName: "lock"
    },
    {
      id: "goal",
      dayRange: "Tag 14",
      title: "Die Schwelle überschreiten",
      description: "Dein erster, voll und ganz bewusst gesteuerter Klartraum.",
      status: "locked",
      iconName: "auto_stories"
    }
  ];

  const [lessons, setLessons] = useState<CourseLesson[]>(initialLessons);

  const handleStartLesson = () => {
    setIsLessonOpen(true);
  };

  const handleCompleteLesson = () => {
    // Transition Day 5 to completed, Day 6 to active or complete
    setIsLessonOpen(false);
    setIsFinished(true);
    setProgress(50); // double progress!

    setLessons(p => 
      p.map(l => {
        if (l.id === "current-mild") {
          return { ...l, status: "completed" };
        }
        if (l.id === "locked-signs") {
          return { ...l, status: "active", description: "Finde wiederkehrende Triggersymbole (z.B. Leuchttürme) in deinem wöchentlichen Journal!" };
        }
        return l;
      })
    );
  };

  return (
    <div className="w-full text-[#dde3eb] animate-fade-in pb-16">
      
      {/* Hero Section */}
      <section className="mb-10 text-center">
        <h2 className="font-headline-lg-mobile text-2xl md:font-headline-lg md:text-3xl text-on-surface mb-2 font-bold tracking-tight">
          Werte Luzide
        </h2>
        <p className="font-body-md text-[#bbc9cd] max-w-xs mx-auto leading-relaxed text-sm">
          Dein Ziel: Der erste bewusste Traum am Tag 14.
        </p>

        {/* Circular Progress SVG Ring */}
        <div className="mt-8 relative inline-flex items-center justify-center">
          <svg className="w-28 h-28 transform -rotate-90">
            {/* Background circle */}
            <circle
              className="text-[#2f353c]"
              cx="56"
              cy="56"
              fill="transparent"
              r="48"
              stroke="currentColor"
              strokeWidth="5"
            ></circle>
            {/* Progress circle */}
            <circle
              className="text-[#2fd9f4] drop-shadow-[0_0_8px_rgba(47,217,244,0.4)] transition-all duration-1000"
              cx="56"
              cy="56"
              fill="transparent"
              r="48"
              stroke="currentColor"
              strokeWidth="5"
              strokeDasharray="301.6"
              strokeDashoffset={301.6 - (301.6 * progress) / 100}
            ></circle>
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
            <span className="font-headline-md text-xl md:text-2xl text-[#8aebff] font-bold">
              {progress}%
            </span>
            <span className="text-[9px] text-[#bbc9cd] uppercase tracking-widest leading-none">
              Fortschritt
            </span>
          </div>
        </div>
      </section>

      {/* Timeline of lessons */}
      <section className="relative space-y-8 pb-12">
        {/* Vertical alignment list line */}
        <div className="absolute left-6 top-4 bottom-4 w-0.5 z-0 bg-gradient-to-b from-[#2fd9f4] via-[#2f353c] to-white/5"></div>

        {lessons.map((lesson) => {
          const isCompleted = lesson.status === "completed";
          const isActive = lesson.status === "active";
          const isLocked = lesson.status === "locked";

          return (
            <div
              key={lesson.id}
              className={`relative flex items-start gap-4 z-10 group transition-all duration-300 ${
                isCompleted ? "opacity-60" : ""
              }`}
            >
              {/* Dynamic Left Round Node representing state */}
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center shrink-0 border-4 border-[#0e141a] transition-all duration-500 ${
                  isCompleted
                    ? "bg-[#2fd9f4] text-[#00363e]"
                    : isActive
                    ? "bg-[#2fd9f4] text-[#00363e] ring-4 ring-[#2fd9f4]/20 animate-pulse font-bold"
                    : "bg-[#2f353c] text-[#bbc9cd]/60"
                }`}
              >
                {isCompleted ? (
                  <Check className="w-5 h-5 font-bold stroke-[3px]" />
                ) : isActive ? (
                  <span className="text-sm font-bold">{lesson.id === "current-mild" ? "05" : "06"}</span>
                ) : lesson.id === "goal" ? (
                  <Compass className="w-4 h-4 text-[#ddb8ff]" />
                ) : (
                  <Lock className="w-4 h-4" />
                )}
              </div>

              {/* Lesson details container block */}
              <div
                className={`p-6 rounded-xl flex-grow border transition-all duration-300 bg-[#1a2026]/40 backdrop-blur-md ${
                  isActive
                    ? "border-[#2fd9f4] shadow-[0_0_20px_rgba(47,217,244,0.15)] bg-[#1a2026]/80"
                    : "border-white/10"
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span
                    className={`font-label-sm text-[10px] uppercase font-bold tracking-wider ${
                      isActive ? "text-[#2fd9f4]" : "text-[#bbc9cd]/60"
                    }`}
                  >
                    {lesson.dayRange}
                  </span>
                  {isActive && (
                    <span className="text-[10px] bg-[#2fd9f4]/15 text-[#2fd9f4] font-semibold uppercase px-2 py-0.5 rounded-full animate-pulse">
                      Heute aktiv
                    </span>
                  )}
                </div>

                <h3 className="font-headline-md text-base md:text-lg font-bold text-on-surface mb-2">
                  {lesson.title}
                </h3>
                <p className="text-xs md:text-sm text-[#bbc9cd] leading-relaxed mb-4">
                  {lesson.description}
                </p>

                {isActive && (
                  <button
                    id={`lesson-start-btn-${lesson.id}`}
                    onClick={handleStartLesson}
                    className="w-full py-3 rounded-full bg-gradient-to-r from-[#8aebff] to-[#ddb8ff] text-[#00363e] text-xs font-bold tracking-wider uppercase shadow-[0_0_15px_rgba(47,217,244,0.3)] hover:scale-103 active:scale-97 transition-all duration-300 cursor-pointer"
                  >
                    Starten
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </section>

      {/* Decorative Blur Orbits behind the content */}
      <div className="fixed top-1/4 -right-24 w-64 h-64 bg-[#8aebff]/5 blur-[120px] rounded-full pointer-events-none -z-10"></div>
      <div className="fixed bottom-1/4 -left-24 w-80 h-80 bg-[#ddb8ff]/5 blur-[120px] rounded-full pointer-events-none -z-10"></div>

      {/* LESSON DETAIL INTERACTIVE EXPAND MODAL SHEET */}
      {isLessonOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="bg-[#161c22] border border-white/10 rounded-2xl p-6 md:p-8 max-w-lg w-full flex flex-col gap-6 shadow-[0_0_50px_rgba(47,217,244,0.2)] animate-scale-up">
            <div className="flex items-center gap-2 text-[#2fd9f4]">
              <Compass className="w-6 h-6 animate-spin" style={{ animationDuration: "12s" }} />
              <h3 className="font-headline-md text-xl font-bold font-display">
                Mission: Reality Checks üben
              </h3>
            </div>

            <div className="text-sm text-[#bbc9cd] space-y-4 max-h-[350px] overflow-y-auto pr-2 custom-scrollbar">
              <p className="leading-relaxed">
                Der Reality-Check ist die wichtigste Waffe eines luziden Träumers. Dein Gehirn hinterfragt den Traumzustand nie von alleine — es sei denn, du bringst ihm bei, <strong>auch im Wachzustand skeptisch zu sein</strong>.
              </p>
              
              <div className="bg-white/5 p-4 rounded-lg space-y-2 border border-white/5">
                <h4 className="text-xs font-bold uppercase text-[#8aebff]">Die 3 stärksten Reality-Checks für heute:</h4>
                <ul className="list-decimal list-inside space-y-2 text-xs">
                  <li><strong>Nasen-Check:</strong> Halte Mund und Nase ganz fest zu. Kannst du trotzdem atmen? Im Traum ja, im Wachleben nein.</li>
                  <li><strong>Uhren-Check:</strong> Schau auf eine Digitaluhr, schau weg, schau wieder hin. Im Traum verändern sich die Zahlen ständig.</li>
                  <li><strong>Hand-Check:</strong> Zähle deine Finger. Sind es genau fünf? Ergibt die Handfläche eine normale Struktur? im Traum verschwimmen sie.</li>
                </ul>
              </div>

              <p className="leading-relaxed">
                <strong>Deine Aufgabe für heute:</strong> Stelle dir alle 2 Stunden einen Timer oder führe immer dann einen Nasen-Check durch, wenn du ein wiederkehrendes Muster siehst (z.B. fließendes Wasser, Leuchttürme oder Vögel).
              </p>
            </div>

            <div className="flex flex-col gap-2 mt-2">
              <button
                id="lesson-complete-done-btn"
                onClick={handleCompleteLesson}
                className="w-full py-4 rounded-full bg-[#2fd9f4] text-[#00363e] font-bold text-xs tracking-wider uppercase shadow-[0_0_15px_rgba(47,217,244,0.2)] hover:scale-102 active:scale-98 transition-all cursor-pointer"
              >
                Mission gestartet: Ich bin bereit!
              </button>
              <button
                id="lesson-cancel-btn"
                onClick={() => setIsLessonOpen(false)}
                className="w-full py-3 rounded-full bg-white/5 hover:bg-white/10 text-xs text-[#bbc9cd] transition-colors"
              >
                Abbrechen
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success completion feedback overlay */}
      {isFinished && (
        <div className="fixed bottom-24 left-4 right-4 md:left-auto md:right-6 bg-gradient-to-r from-teal-500 to-emerald-600 border border-emerald-400 text-[#00363e] px-4 py-3 rounded-xl shadow-lg flex items-center justify-between z-[90] animate-slide-up">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-200 animate-bounce" />
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Glückwunsch! Tag 5 wurde initiiert. Fortschritt +25%
            </span>
          </div>
          <button
            onClick={() => setIsFinished(false)}
            className="text-white hover:text-emerald-200 text-xs font-bold px-2 ml-4"
          >
            Ausblenden
          </button>
        </div>
      )}
    </div>
  );
}
