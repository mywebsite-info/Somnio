/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RemPeak } from "../types";

/**
 * Parses a "HH:MM" string and returns hours and minutes
 */
export function parseTimeString(timeStr: string): { hours: number; minutes: number } {
  const parts = timeStr.trim().split(":");
  const hours = parseInt(parts[0] || "23", 10);
  const minutes = parseInt(parts[1] || "00", 10);
  return {
    hours: isNaN(hours) ? 23 : Math.min(23, Math.max(0, hours)),
    minutes: isNaN(minutes) ? 0 : Math.min(59, Math.max(0, minutes)),
  };
}

/**
 * Calculates the REM sleep cycles based on start sleep time
 */
export function calculateSleepCycles(sleepTimeStr: string): RemPeak[] {
  const { hours, minutes } = parseTimeString(sleepTimeStr);
  const baseDate = new Date();
  baseDate.setHours(hours, minutes, 0, 0);

  const peaks: RemPeak[] = [];
  
  // REM phases happen roughly every 90 minutes.
  // Standard model includes 6 cycles.
  // The 4th cycle peak falls around 4.5h to 6.0h (peak around ~5h 15m)
  for (let cycleNum = 1; cycleNum <= 6; cycleNum++) {
    // End of the cycle is cycleNum * 90 minutes.
    // The peak of REM is usually towards the end of each cycle, e.g., 10-15 minutes before the cycle end.
    const totalMinutes = cycleNum * 90 - 15;
    
    const peakDate = new Date(baseDate.getTime() + totalMinutes * 60000);
    const h = String(peakDate.getHours()).padStart(2, "0");
    const m = String(peakDate.getMinutes()).padStart(2, "0");
    const peakTimeStr = `${h}:${m} Uhr`;

    let lucidityChance = 10;
    let isOptimalAnker = false;
    let durationMinutes = 10;

    // Progression of REM length and clarity chance
    if (cycleNum === 1) {
      lucidityChance = 5;
      durationMinutes = 5;
    } else if (cycleNum === 2) {
      lucidityChance = 15;
      durationMinutes = 10;
    } else if (cycleNum === 3) {
      lucidityChance = 35;
      durationMinutes = 15;
    } else if (cycleNum === 4) {
      // The Golden Peak specified: 4th sleep phase (4.5 to 6 hours) is optimal
      lucidityChance = 85; 
      isOptimalAnker = true;
      durationMinutes = 25;
    } else if (cycleNum === 5) {
      lucidityChance = 70;
      durationMinutes = 35;
    } else if (cycleNum === 6) {
      lucidityChance = 60;
      durationMinutes = 40;
    }

    peaks.push({
      phase: cycleNum,
      timeString: peakTimeStr,
      durationMinutes,
      lucidityChance,
      isOptimalAnker,
    });
  }

  return peaks;
}
