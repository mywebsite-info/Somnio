/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Clean a raw dream symbol or keyword down to exactly ONE clean singular noun.
 * Implements the 6 linguistic reduction levels specified in the specification.
 */
export function cleanSymbol(input: string): string {
  if (!input) return "";

  let current = input.trim();

  // 1. Meta-Filterung (Blacklisting)
  const blacklist = [
    "kontext",
    "kein",
    "keine",
    "nicht vorhanden",
    "unbekannt",
    "undefiniert",
    "traum",
    "klarheit",
    "wachsein"
  ];
  const lower = current.toLowerCase();
  for (const b of blacklist) {
    if (lower.includes(b)) {
      return "";
    }
  }

  // 2. Artikel- & Pronomen-Schnitt
  // ^(der|die|das|ein|eine|mein|meine|dein|deine|einige|viele|große|großer|kleine|kleiner)\s+ (case-insensitive)
  const articleRegex = /^(der|die|das|ein|eine|mein|meine|dein|deine|einige|viele|große|großer|kleine|kleiner)\s+/i;
  current = current.replace(articleRegex, "");

  // 3. Beschreibungsschnitt (Präpositionen & Konjunktionen sowie Interpunktion)
  const splitTriggers = [
    " als ", " in ", " mit ", " vor ", " am ", " im ", " über ", " von ", " durch ", " auf ",
    ",", ";", ":", "-", "(", "–"
  ];
  
  let earliestIndex = -1;
  let triggerLength = 0;

  for (const trigger of splitTriggers) {
    const idx = current.toLowerCase().indexOf(trigger);
    if (idx !== -1) {
      if (earliestIndex === -1 || idx < earliestIndex) {
        earliestIndex = idx;
        triggerLength = trigger.length;
      }
    }
  }

  if (earliestIndex !== -1) {
    current = current.substring(0, earliestIndex);
  }

  // 4. Erster-Wort-Extraktor & Zeichenbereinigung
  current = current.trim();
  const words = current.split(/\s+/);
  let firstWord = words[0] || "";

  // Remove punctuation restlos: [.,\/#!$%\^&\*;:{}=\-_~()?"'»«]
  const punctuationRegex = /[.,\/#!$%\^&\*;:{}=\-_~()?"'»«]/g;
  firstWord = firstWord.replace(punctuationRegex, "");

  // 5. Kurzwort- & Validitätsinspektion
  const cleanedLower = firstWord.toLowerCase();
  const fillwords = ["nicht", "noch", "da"];
  if (firstWord.length < 3 || fillwords.includes(cleanedLower)) {
    return "";
  }

  // 6. Grammatikalische Normalisierung
  const capitalized = firstWord.charAt(0).toUpperCase() + firstWord.slice(1).toLowerCase();

  return capitalized;
}

/**
 * Helper to clean a list of raw items using the Trigger Codex, weeding out empties.
 */
export function cleanSymbolsList(items: string[]): string[] {
  if (!items) return [];
  return items
    .map(cleanSymbol)
    .filter((v) => v !== "");
}
