/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface SymbolItem {
  name: string;
  emoji: string;
}

export interface SymbolsGroup {
  characters: SymbolItem[];
  locations: SymbolItem[];
  objects: SymbolItem[];
}

export interface InterpretationDetails {
  meaning: string;
  recommendation: string;
}

export interface DreamAnalysis {
  title: string;
  analysis: string;
  lucidityScoreEstimate: number; // 1-10
  isLucid: boolean;
  interpretation: InterpretationDetails;
  emotions: {
    freude: number;       // 0-100%
    vertrauen: number;    // 0-100%
    angst: number;        // 0-100%
    ueberraschung: number;// 0-100%
    traurigkeit: number;  // 0-100%
    ekel: number;         // 0-100%
    wut: number;          // 0-100%
    erwartung: number;    // 0-100%
  };
  symbols: SymbolsGroup;
  dreamSigns: string[];
  imageUrl?: string;
}

export interface DreamEntry {
  id: string;
  text: string;
  date: string; // e.g., "24. OKTOBER 2023 • 04:12 UHR"
  rawDate: string; // ISO String
  clarity: "Trüb" | "Mittel" | "Luzide";
  mood: "Glücklich" | "Ängstlich" | "Neutral";
  isLucid: boolean;
  analysis: DreamAnalysis;
  username?: string;
}

export interface RemPeak {
  phase: number;
  timeString: string;
  durationMinutes: number;
  lucidityChance: number; // 0-100
  isOptimalAnker: boolean;
}

export interface CourseLesson {
  id: string;
  dayRange: string; // e.g. "Tag 1-4"
  title: string;
  description: string;
  status: "completed" | "active" | "locked";
  iconName: string;
}
