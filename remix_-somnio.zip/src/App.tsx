/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import AppBar from "./components/AppBar";
import BottomNav from "./components/BottomNav";
import Dashboard from "./components/Dashboard";
import Editor from "./components/Editor";
import AnalysisView from "./components/AnalysisView";
import CourseView from "./components/CourseView";
import SettingsModal from "./components/SettingsModal";
import RealityCheckOverlay from "./components/RealityCheckOverlay";
import LoginScreen from "./components/LoginScreen";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import { DreamEntry, DreamAnalysis } from "./types";
import { Sparkles, CloudCheck, Moon, ShieldCheck, HelpCircle, Eye, RefreshCw, X, Trash2, LogOut } from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"home" | "journal" | "analysis" | "course">("home");
  const [entries, setEntries] = useState<DreamEntry[]>([]);
  const [selectedEntry, setSelectedEntry] = useState<DreamEntry | null>(null);
  const [showOverlay, setShowOverlay] = useState(true);
  const [username, setUsername] = useState<string>(() => {
    return localStorage.getItem("somnio_username") || localStorage.getItem("somneo_username") || localStorage.getItem("luziden_username") || "";
  });
  
  // Active temporary draft is created when analyzing but before saving
  const [draftEntry, setDraftEntry] = useState<DreamEntry | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  
  // Modals & Panels UI State
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  // Seed / Sync from server-side database
  const fetchLogs = async (currentUser = username) => {
    if (!currentUser) return;
    try {
      const response = await fetch(`/api/journal?username=${encodeURIComponent(currentUser)}`);
      if (response.ok) {
        const data = await response.json();
        setEntries(data);
      }
    } catch (err) {
      console.error("Fehler beim Abrufen des Journals vom Server:", err);
    }
  };

  useEffect(() => {
    if (username) {
      fetchLogs(username);
    }
  }, [username]);

  // --- LUCIDITY INDEX & PROGRESS MATHS ---
  const totalDreamsCount = entries.length;
  const lucidDreamsCount = entries.filter((e) => e.isLucid).length;
  
  // Lucidity Rate = (Klarträume / Gesamteinträge) * 100
  const lucidityRate = totalDreamsCount > 0 ? (lucidDreamsCount / totalDreamsCount) * 100 : 0;

  // Let's decide Lucidity Tiers
  // If LR_d <= 10: „Erwachender Geist“ (Initialisierungszustand)
  // If 10 < LR_d <= 30: „Traumnovize“ (Einstiegszustand)
  // If 30 < LR_d <= 60: „Schwellenwanderer“ (Fortgeschritten)
  // If LR_d > 60: „Astral-Meister“ (Optimale Klarheitskontrolle)
  const getLucidityTier = (rate: number, count: number): string => {
    if (count === 0) return "Erwachender Geist (Initialisiert)";
    if (rate <= 10) return "Erwachender Geist";
    if (rate <= 30) return "Traumnovize";
    if (rate <= 60) return "Schwellenwanderer";
    return "Astral-Meister";
  };

  const lucidityTier = getLucidityTier(lucidityRate, totalDreamsCount);

  // Logisches Ratschlag-Mapping
  const getLucidityAdvice = (rate: number, count: number): string => {
    if (count === 0) {
      return "Keine Einträge vorhanden. Bitte zeichne deinen ersten Traum auf, um deinen astralen Lucidity-Index zu kalibrieren.";
    }
    if (rate <= 10) {
      return "Fokus auf die Erfassung von Kleinstdetails zur Reaktivierung der Traumerinnerung.";
    }
    if (rate <= 30) {
      return "Empfehlung für intensivere Reality-Checks am Tag.";
    }
    if (rate <= 60) {
      return "Empfehlung spezialisierter Techniken (WBTB / Wake-Back-To-Bed, Pre-Sleep-Meditation).";
    }
    return "Instruktion zur Erforschung fortgeschrittener Klartraumsteuerung (z.B. Flugphysik).";
  };

  const pathAdvice = getLucidityAdvice(lucidityRate, totalDreamsCount);

  // Trigger full-stack analyze sequence
  const handleAnalyzeDream = async (payload: {
    text: string;
    clarity: "Trüb" | "Mittel" | "Luzide";
    mood: "Glücklich" | "Ängstlich" | "Neutral";
  }) => {
    setIsAnalyzing(true);
    try {
      const isLucidUser = payload.clarity === "Luzide";
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: payload.text,
          clarity: payload.clarity,
          mood: payload.mood,
          isLucidUser,
        }),
      });

      if (!response.ok) {
        let errorMsg = "Fehler bei der Kommunikation mit dem Analyse-Server.";
        try {
          const errData = await response.json();
          if (errData && errData.error) {
            errorMsg = `Analysefehler: ${errData.error}${errData.details ? ` (${errData.details})` : ""}`;
          }
        } catch (_) {}
        throw new Error(errorMsg);
      }

      const analysisResult: DreamAnalysis = await response.json();

      // Format clean readable German Date
      const now = new Date();
      const months = [
        "Januar", "Februar", "März", "April", "Mai", "Juni",
        "Juli", "August", "September", "Oktober", "November", "Dezember"
      ];
      const day = now.getDate();
      const month = months[now.getMonth()].toUpperCase();
      const year = now.getFullYear();
      const hrs = String(now.getHours()).padStart(2, "0");
      const mins = String(now.getMinutes()).padStart(2, "0");
      const formattedDate = `${day}. ${month} ${year} • ${hrs}:${mins} UHR`;

      // Build draft dream object
      const newDraft: DreamEntry = {
        id: `dream-${Date.now()}`,
        text: payload.text,
        date: formattedDate,
        rawDate: now.toISOString(),
        clarity: payload.clarity,
        mood: payload.mood,
        isLucid: analysisResult.isLucid,
        analysis: analysisResult,
        username,
      };

      setDraftEntry(newDraft);
      setSelectedEntry(null);
      setIsSaved(false);
      
      // Auto move user to analysis screen immediately to focus on output
      setActiveTab("analysis");
    } catch (err: any) {
      alert(err.message || "Unerwarteter Analysefehler.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Triggers final REST saving to server-side JSON persistence
  const handleSaveToJournal = async () => {
    const entryToSave = draftEntry || selectedEntry;
    if (!entryToSave) return;

    try {
      const response = await fetch("/api/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...entryToSave, username }),
      });

      if (response.ok) {
        setIsSaved(true);
        // Sync local representation
        await fetchLogs();
      } else {
        alert("Fehler beim Sichern des Traums im Journal.");
      }
    } catch (err) {
      console.error(err);
      alert("Es konnte keine Verbindung zum Sichern aufgebaut werden.");
    }
  };

  // Delete a dream
  const handleDeleteDream = async (id: string) => {
    try {
      const confirmDel = window.confirm("Möchtest du diesen Eintrag wirklich aus deinem Journal löschen?");
      if (!confirmDel) return;

      // Optimistic layout update for instantaneous responsiveness
      setEntries((prev) => prev.filter((entry) => entry.id !== id));
      setSelectedEntry(null);
      setDraftEntry(null);
      setIsSaved(false);

      const response = await fetch(`/api/journal/${id}`, {
        method: "DELETE"
      });

      if (response.ok) {
        await fetchLogs();
        setActiveTab("home");
      } else {
        // Fallback if deletion failed on server
        await fetchLogs();
        alert("Eintrag konnte nicht vom Server gelöscht werden.");
      }
    } catch (err) {
      console.error(err);
      await fetchLogs();
    }
  };

  // Danger-zone wipeout
  const handleWipeoutJournal = async () => {
    try {
      // Create empty payload on the server or delete sequentially
      for (const entry of entries) {
        await fetch(`/api/journal/${entry.id}`, { method: "DELETE" });
      }
      setEntries([]);
      setSelectedEntry(null);
      setDraftEntry(null);
      setIsSaved(false);
      setIsSettingsOpen(false);
      setActiveTab("home");
      alert("Traum-Journal wurde erfolgreich zurückgesetzt.");
    } catch (err) {
      console.error(err);
    }
  };

  const handleEntryClick = (entry: DreamEntry) => {
    setSelectedEntry(entry);
    setDraftEntry(null);
    setIsSaved(true);
  };

  const handleTabChange = (tab: "home" | "journal" | "analysis" | "course") => {
    setActiveTab(tab);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleLogout = () => {
    if (window.confirm("Möchtest du dich wirklich abmelden? Deine Träume bleiben auf unserem Server gespeichert.")) {
      localStorage.removeItem("somnio_username");
      localStorage.removeItem("somneo_username");
      localStorage.removeItem("luziden_username");
      setUsername("");
      setEntries([]);
      setSelectedEntry(null);
      setDraftEntry(null);
      setIsSettingsOpen(false);
      setIsDrawerOpen(false);
      setActiveTab("home");
    }
  };

  if (!username) {
    return (
      <LoginScreen
        onLogin={(newUser) => {
          setUsername(newUser);
          localStorage.setItem("somnio_username", newUser);
        }}
      />
    );
  }

  return (
    <div className="bg-[#0e141a] text-[#dde3eb] min-h-screen relative font-sans antialiased overflow-x-hidden">
      {/* Aurora Atmospheric Blurs */}
      <div className="fixed top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full bg-[#8aebff]/5 blur-[120px] pointer-events-none z-0"></div>
      <div className="fixed bottom-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full bg-[#ddb8ff]/5 blur-[150px] pointer-events-none z-0"></div>

      {/* Top App bar */}
      <AppBar
        title="Somnio"
        showBack={activeTab === "analysis" && (draftEntry !== null || selectedEntry !== null)}
        onBack={() => {
          setSelectedEntry(null);
          setDraftEntry(null);
          setActiveTab("home");
        }}
        showProfile={activeTab === "home"}
        onProfileClick={() => setIsDrawerOpen(true)}
        onShareClick={() => {
          const shareText = "Teile diesen Klartraum von Somnio - Verbinde Kopf und Traum!";
          if (navigator.share) {
            navigator.share({ title: "Somnio Traum", text: shareText, url: window.location.href }).catch(() => {});
          } else {
            navigator.clipboard.writeText(shareText);
            alert("Teilen-Link in Zwischenablage kopiert!");
          }
        }}
        onSettingsClick={() => setIsSettingsOpen(true)}
      />

      {/* Slide-out Sidebar Drawer Menü */}
      {isDrawerOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          {/* Overlay backdrop */}
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
            onClick={() => setIsDrawerOpen(false)}
          ></div>
          
          <aside className="fixed left-0 top-0 bottom-0 max-w-sm w-full bg-[#242b31]/95 backdrop-blur-2xl border-r border-white/5 shadow-2xl p-6 flex flex-col justify-between h-full z-10 transition-transform duration-300">
            <div className="space-y-6">
              <div className="flex justify-between items-center pb-4 border-b border-white/5">
                <h3 className="font-headline-md text-xl font-bold font-display text-[#8aebff]">
                  Aktivitäts-Zentrale
                </h3>
                <button
                  id="drawer-close-btn"
                  onClick={() => setIsDrawerOpen(false)}
                  className="p-1 px-2 text-[#bbc9cd] hover:text-white rounded-lg hover:bg-white/5"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* User badge */}
              <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/5">
                <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#8aebff] to-[#ddb8ff] flex items-center justify-center font-bold text-[#00363e] uppercase">
                  {username ? username.slice(0, 2) : "TR"}
                </div>
                <div>
                  <p className="font-bold text-[#dde3eb]">{username || "Träumer"}</p>
                  <p className="text-xs text-[#2fd9f4] font-semibold uppercase tracking-wider">
                    {lucidityTier}
                  </p>
                </div>
              </div>

              {/* Drawer Links */}
              <nav className="space-y-1">
                <button
                  onClick={() => {
                    alert(`Astraler lucidity-index: ${Math.round(lucidityRate)}% basierend auf ${lucidDreamsCount} Klarträumen.`);
                    setIsDrawerOpen(false);
                  }}
                  className="w-full flex items-center gap-3 p-3 text-sm font-medium text-[#dde3eb] hover:bg-white/5 rounded-lg transition-colors text-left"
                >
                  <Sparkles className="w-4 h-4 text-[#8aebff]" /> Personal Stats
                </button>
                <button
                  onClick={() => {
                    alert(`Cloud-Synchronisierung aktiv für Benutzer: ${username}. Alle luziden Träume sind online gesichert ✓`);
                    setIsDrawerOpen(false);
                  }}
                  className="w-full flex items-center gap-3 p-3 text-sm font-medium text-[#dde3eb] hover:bg-white/5 rounded-lg transition-colors text-left"
                >
                  <CloudCheck className="w-4 h-4 text-emerald-400" /> Cloud Sync
                </button>
                <button
                  onClick={() => {
                    alert("Schlafsounds werden geladen: 'Caelum Theta Pulsing', 'Rhythm of Deep Ocean'...");
                    setIsDrawerOpen(false);
                  }}
                  className="w-full flex items-center gap-3 p-3 text-sm font-medium text-[#dde3eb] hover:bg-white/5 rounded-lg transition-colors text-left"
                >
                  <Moon className="w-4 h-4 text-[#ddb8ff]" /> Sleep Sounds
                </button>
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-3 p-3 text-sm font-medium text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors text-left cursor-pointer"
                >
                  <LogOut className="w-4 h-4 text-rose-400" /> Abmelden
                </button>
              </nav>
            </div>

            {/* Bottom info */}
            <div className="pt-4 border-t border-white/5 text-xs text-[#bbc9cd]/60 space-y-1">
              <p className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Verschlüsselt mit Somnio Core
              </p>
              <p>{totalDreamsCount} Träume aufgezeichnet</p>
            </div>
          </aside>
        </div>
      )}

      {/* Main Container Stage */}
      <main className="relative z-10 pt-24 pb-32 px-6 max-w-[1200px] mx-auto min-h-screen">
        
        {/* Dynamic Route/View Switcher */}
        {activeTab === "home" && (
          <Dashboard
            entries={entries}
            lucidityRate={lucidityRate}
            lucidityTier={lucidityTier}
            onNewDreamClick={() => setActiveTab("journal")}
            onEntryClick={handleEntryClick}
            onDeleteEntry={handleDeleteDream}
          />
        )}

        {activeTab === "journal" && (
          <Editor onAnalyze={handleAnalyzeDream} isLoading={isAnalyzing} />
        )}

        {activeTab === "analysis" && (
          <AnalyticsDashboard entries={entries} />
        )}

        {activeTab === "course" && <CourseView />}
      </main>

      {/* Individual Dream Details/Analysis Modal Overlay */}
      {(draftEntry || selectedEntry) && (
        <div className="fixed inset-0 bg-[#0c1015]/98 backdrop-blur-xl z-[90] overflow-y-auto px-4 py-16 md:px-8">
          <div className="max-w-[1000px] mx-auto relative bg-[#12181e] p-6 md:p-10 rounded-2xl border border-white/10 shadow-[0_0_80px_rgba(47,217,244,0.15)] animate-scale-up">
            
            {/* Top Toolbar */}
            <div className="flex justify-between items-center mb-6 pb-4 border-b border-white/5">
              <span className="text-[#8aebff] text-xs font-bold uppercase tracking-widest flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 animate-pulse" /> {draftEntry ? "Neue Traumsynthese" : "Journal-Eintrag"}
              </span>
              <div className="flex items-center gap-4">
                {selectedEntry && (
                  <button
                    id="analysis-delete-btn"
                    onClick={() => handleDeleteDream(selectedEntry.id)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-500/20 hover:bg-rose-500/10 text-rose-400 text-xs font-semibold cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" /> Traum löschen
                  </button>
                )}
                {draftEntry && (
                  <button
                    onClick={() => {
                      if (window.confirm("Möchtest du diese Analyse wirklich verwerfen?")) {
                        setDraftEntry(null);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/10 hover:bg-white/5 text-[#bbc9cd] text-xs font-semibold cursor-pointer transition-colors"
                  >
                    Analyse verwerfen
                  </button>
                )}
                <button
                  onClick={() => {
                    setSelectedEntry(null);
                    setDraftEntry(null);
                  }}
                  className="p-1.5 rounded-full hover:bg-white/5 text-[#bbc9cd] hover:text-white transition-colors cursor-pointer"
                  title="Schließen"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <AnalysisView
              analysis={draftEntry ? draftEntry.analysis : selectedEntry!.analysis}
              dateStr={draftEntry ? draftEntry.date : selectedEntry!.date}
              isSaved={isSaved}
              onSave={async () => {
                await handleSaveToJournal();
                setDraftEntry(null);
                setSelectedEntry(null);
              }}
              onClose={() => {
                setDraftEntry(null);
                setSelectedEntry(null);
              }}
            />
          </div>
        </div>
      )}

      {/* Settings & REM Peak Modeling Modal */}
      {isSettingsOpen && (
        <SettingsModal
          onClose={() => setIsSettingsOpen(false)}
          onClearJournal={handleWipeoutJournal}
          onLogout={handleLogout}
        />
      )}

      {/* Persistent Navigation tab bar */}
      <BottomNav activeTab={activeTab} onTabChange={handleTabChange} />

      {/* Fullscreen interactive 5 second Reality Check Countdown overlay on load */}
      {showOverlay && (
        <RealityCheckOverlay onComplete={() => setShowOverlay(false)} />
      )}
    </div>
  );
}
